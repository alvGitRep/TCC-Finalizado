<?php
session_start();

// Verifica se há 10 cartas da etapa anterior
if (!isset($_SESSION['etapa1']) || count($_SESSION['etapa1']) !== 10) {
    header("Location: etapa1.php");
    exit();
}

$cartasSelecionadas = $_SESSION['etapa1'];

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "astrodb");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Se formulário enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['cartas']) && count($_POST['cartas']) == 3) {
        $_SESSION['etapa2'] = $_POST['cartas'];
        header("Location: etapa3.php");
        exit();
    } else {
        $erro = "Você deve escolher exatamente 3 cartas.";
    }
}

// Buscar as 10 cartas selecionadas anteriormente
$ids = implode(",", array_map('intval', $cartasSelecionadas));
$sql = "SELECT * FROM cartas_tarot WHERE id IN ($ids)";
$result = $conn->query($sql);

$cartas = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cartas[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AstroRealm: Etapa 2 - Escolha 3 Cartas</title>
    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/etapas.css">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
    <script src="../js/cssGeral.js" defer></script>
    <script>
        function limitarSelecao(checkbox) {
            const selecionados = document.querySelectorAll('input[type="checkbox"]:checked');
            if (selecionados.length > 3) {
                checkbox.checked = false;
                alert("Você só pode escolher 3 cartas.");
            }
        }
    </script>
</head>

<body>
    <div id="content">
        <header>
            <!-- <div id="contato"></div> -->
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <span class="dropdown-toggle">▼</span>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php" class="underline">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                    <li class="menuItem"><a href="../admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="../perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="../login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>

        </header>
    </div>

    <div id="etapasContainer">
        <h1>Escolha 3 Cartas</h1>
        <p>Entre as 10 cartas escolhidas anteriormente, selecione 3 que mais chamam sua atenção.</p>

        <?php if (!empty($erro)): ?>
            <p style="color:red;"><?= $erro ?></p>
        <?php endif; ?>

        <form method="POST">
            <div class="cartas-container">
                <?php foreach ($cartas as $carta): ?>
                    <div class="carta">
                        <input type="checkbox" name="cartas[]" value="<?= $carta['id'] ?>" id="carta<?= $carta['id'] ?>" onchange="limitarSelecao(this)">
                        <label for="carta<?= $carta['id'] ?>">
                            <img src="../imagens/cartas/<?= basename($carta['imagem']) ?>" alt="<?= $carta['nome'] ?>">
                            <p><?= $carta['nome'] ?></p>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="submit">Avançar para a Etapa 3</button>
        </form>
    </div>



</body>

</html>