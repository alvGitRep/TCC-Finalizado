<?php
session_start();
require_once "conexao.php"; // sua conexão com o banco

// Recebe JSON bruto
$data = json_decode(file_get_contents("php://input"), true);

if (isset($_SESSION['usuario_id']) && isset($data['mapa'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $mapa = $data['mapa'];

    $stmt = $conn->prepare("INSERT INTO mapas_astrais (usuario_id, dados_mapa, data_criacao) VALUES (?, ?, NOW())");
    $stmt->bind_param("is", $usuario_id, $mapa);

    if ($stmt->execute()) {
        echo "Mapa salvo com sucesso!";
    } else {
        echo "Erro ao salvar no banco.";
    }

    $stmt->close();
} else {
    echo "Dados incompletos ou usuário não autenticado.";
}

$conn->close();
?>
