-- Inserção dos Arcanos Menores (IDs 23 a 78)
INSERT INTO cartas_tarot (id, nome, tipo, imagem, significado) VALUES
-- Paus (23 a 36)
(23, 'Ás de Paus', 'Arcano Menor', 'as_de_paus.jpg', 'Início, inspiração e potencial'),
(24, '2 de Paus', 'Arcano Menor', '2_de_paus.jpg', 'Equilíbrio, parcerias e escolhas'),
(25, '3 de Paus', 'Arcano Menor', '3_de_paus.jpg', 'Crescimento, criatividade e ação inicial'),
(26, '4 de Paus', 'Arcano Menor', '4_de_paus.jpg', 'Estabilidade, estrutura e manifestação'),
(27, '5 de Paus', 'Arcano Menor', '5_de_paus.jpg', 'Conflito, mudança e desafio'),
(28, '6 de Paus', 'Arcano Menor', '6_de_paus.jpg', 'Harmonia, progresso e generosidade'),
(29, '7 de Paus', 'Arcano Menor', '7_de_paus.jpg', 'Avaliação, fé e perseverança'),
(30, '8 de Paus', 'Arcano Menor', '8_de_paus.jpg', 'Movimento, ação rápida e mudança'),
(31, '9 de Paus', 'Arcano Menor', '9_de_paus.jpg', 'Maturidade, realizações e introspecção'),
(32, '10 de Paus', 'Arcano Menor', '10_de_paus.jpg', 'Conclusão, fardo e responsabilidade'),
(33, 'Valete de Paus', 'Arcano Menor', 'valete_de_paus.jpg', 'Novas ideias, mensagens e curiosidade'),
(34, 'Cavaleiro de Paus', 'Arcano Menor', 'cavaleiro_de_paus.jpg', 'Missão, determinação e impulso'),
(35, 'Rainha de Paus', 'Arcano Menor', 'rainha_de_paus.jpg', 'Compreensão, intuição e cuidado'),
(36, 'Rei de Paus', 'Arcano Menor', 'rei_de_paus.jpg', 'Liderança, domínio e maturidade'),
-- Copas (37 a 50)
(37, 'Ás de Copas', 'Arcano Menor', 'as_de_copas.jpg', 'Início, inspiração e potencial'),
(38, '2 de Copas', 'Arcano Menor', '2_de_copas.jpg', 'Equilíbrio, parcerias e escolhas'),
(39, '3 de Copas', 'Arcano Menor', '3_de_copas.jpg', 'Crescimento, criatividade e ação inicial'),
(40, '4 de Copas', 'Arcano Menor', '4_de_copas.jpg', 'Estabilidade, estrutura e manifestação'),
(41, '5 de Copas', 'Arcano Menor', '5_de_copas.jpg', 'Conflito, mudança e desafio'),
(42, '6 de Copas', 'Arcano Menor', '6_de_copas.jpg', 'Harmonia, progresso e generosidade'),
(43, '7 de Copas', 'Arcano Menor', '7_de_copas.jpg', 'Avaliação, fé e perseverança'),
(44, '8 de Copas', 'Arcano Menor', '8_de_copas.jpg', 'Movimento, ação rápida e mudança'),
(45, '9 de Copas', 'Arcano Menor', '9_de_copas.jpg', 'Maturidade, realizações e introspecção'),
(46, '10 de Copas', 'Arcano Menor', '10_de_copas.jpg', 'Conclusão, fardo e responsabilidade'),
(47, 'Valete de Copas', 'Arcano Menor', 'valete_de_copas.jpg', 'Novas ideias, mensagens e curiosidade'),
(48, 'Cavaleiro de Copas', 'Arcano Menor', 'cavaleiro_de_copas.jpg', 'Missão, determinação e impulso'),
(49, 'Rainha de Copas', 'Arcano Menor', 'rainha_de_copas.jpg', 'Compreensão, intuição e cuidado'),
(50, 'Rei de Copas', 'Arcano Menor', 'rei_de_copas.jpg', 'Liderança, domínio e maturidade'),
-- Espadas (51 a 64)
(51, 'Ás de Espadas', 'Arcano Menor', 'as_de_espadas.jpg', 'Início, inspiração e potencial'),
(52, '2 de Espadas', 'Arcano Menor', '2_de_espadas.jpg', 'Equilíbrio, parcerias e escolhas'),
(53, '3 de Espadas', 'Arcano Menor', '3_de_espadas.jpg', 'Crescimento, criatividade e ação inicial'),
(54, '4 de Espadas', 'Arcano Menor', '4_de_espadas.jpg', 'Estabilidade, estrutura e manifestação'),
(55, '5 de Espadas', 'Arcano Menor', '5_de_espadas.jpg', 'Conflito, mudança e desafio'),
(56, '6 de Espadas', 'Arcano Menor', '6_de_espadas.jpg', 'Harmonia, progresso e generosidade'),
(57, '7 de Espadas', 'Arcano Menor', '7_de_espadas.jpg', 'Avaliação, fé e perseverança'),
(58, '8 de Espadas', 'Arcano Menor', '8_de_espadas.jpg', 'Movimento, ação rápida e mudança'),
(59, '9 de Espadas', 'Arcano Menor', '9_de_espadas.jpg', 'Maturidade, realizações e introspecção'),
(60, '10 de Espadas', 'Arcano Menor', '10_de_espadas.jpg', 'Conclusão, fardo e responsabilidade'),
(61, 'Valete de Espadas', 'Arcano Menor', 'valete_de_espadas.jpg', 'Novas ideias, mensagens e curiosidade'),
(62, 'Cavaleiro de Espadas', 'Arcano Menor', 'cavaleiro_de_espadas.jpg', 'Missão, determinação e impulso'),
(63, 'Rainha de Espadas', 'Arcano Menor', 'rainha_de_espadas.jpg', 'Compreensão, intuição e cuidado'),
(64, 'Rei de Espadas', 'Arcano Menor', 'rei_de_espadas.jpg', 'Liderança, domínio e maturidade'),
-- Ouros (65 a 78)
(65, 'Ás de Ouros', 'Arcano Menor', 'as_de_ouros.jpg', 'Início, inspiração e potencial'),
(66, '2 de Ouros', 'Arcano Menor', '2_de_ouros.jpg', 'Equilíbrio, parcerias e escolhas'),
(67, '3 de Ouros', 'Arcano Menor', '3_de_ouros.jpg', 'Crescimento, criatividade e ação inicial'),
(68, '4 de Ouros', 'Arcano Menor', '4_de_ouros.jpg', 'Estabilidade, estrutura e manifestação'),
(69, '5 de Ouros', 'Arcano Menor', '5_de_ouros.jpg', 'Conflito, mudança e desafio'),
(70, '6 de Ouros', 'Arcano Menor', '6_de_ouros.jpg', 'Harmonia, progresso e generosidade'),
(71, '7 de Ouros', 'Arcano Menor', '7_de_ouros.jpg', 'Avaliação, fé e perseverança'),
(72, '8 de Ouros', 'Arcano Menor', '8_de_ouros.jpg', 'Movimento, ação rápida e mudança'),
(73, '9 de Ouros', 'Arcano Menor', '9_de_ouros.jpg', 'Maturidade, realizações e introspecção'),
(74, '10 de Ouros', 'Arcano Menor', '10_de_ouros.jpg', 'Conclusão, fardo e responsabilidade'),
(75, 'Valete de Ouros', 'Arcano Menor', 'valete_de_ouros.jpg', 'Novas ideias, mensagens e curiosidade'),
(76, 'Cavaleiro de Ouros', 'Arcano Menor', 'cavaleiro_de_ouros.jpg', 'Missão, determinação e impulso'),
(77, 'Rainha de Ouros', 'Arcano Menor', 'rainha_de_ouros.jpg', 'Compreensão, intuição e cuidado'),
(78, 'Rei de Ouros', 'Arcano Menor', 'rei_de_ouros.jpg', 'Liderança, domínio e maturidade');

-- Naipe de Paus
UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Ás de Paus: A Centelha da Inspiração",
    "introducao": "O Ás de Paus simboliza o início de uma jornada criativa, cheia de paixão, energia e inspiração. Representa a centelha divina que acende novos projetos, aventuras ou ideias, como uma chama que promete crescimento e transformação.",
    "simbologia": "No Rider-Waite, uma mão divina emerge das nuvens segurando um bastão verdejante, simbolizando potencial criativo. O cenário com um rio e montanhas reflete vitalidade, enquanto o castelo ao fundo sugere conquistas futuras.",
    "significados": {
        "direita": "Inspiração, criatividade, novos começos, paixão, energia. O Ás de Paus convida a abraçar novas ideias com entusiasmo.",
        "invertida": "Falta de motivação, atrasos, bloqueio criativo, energia dispersa. Pode indicar hesitação ou dificuldade em iniciar projetos."
    },
    "contextos": {
        "amor": "Paixão renovada ou um novo romance cheio de energia. Invertida, sugere desinteresse ou falta de conexão emocional.",
        "carreira": "Novos projetos ou oportunidades criativas. Invertida, alerta para procrastinação ou falta de direção profissional.",
        "saude": "Vitalidade elevada, ideal para atividades físicas. Invertida, pode indicar esgotamento ou falta de energia.",
        "espiritualidade": "Despertar espiritual guiado pela paixão. Invertida, sugere desconexão ou dificuldade em encontrar propósito."
    },
    "curiosidade": "O Ás de Paus é associado ao elemento Fogo, que rege a criatividade, a paixão e a energia transformadora."
}' WHERE id = 23;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dois de Paus: A Visão do Futuro",
    "introducao": "O Dois de Paus simboliza planejamento, visão e decisão. Representa o momento de contemplar o horizonte, avaliando opções e reunindo coragem para expandir além do conhecido, como um explorador que sonha com novas terras.",
    "simbologia": "No Rider-Waite, um homem segura um bastão e um globo, olhando para o mar, simbolizando visão e ambição. O segundo bastão fixo sugere estabilidade, enquanto o castelo e montanhas refletem conquistas e desafios.",
    "significados": {
        "direita": "Planejamento, visão, decisão, expansão, coragem. O Dois de Paus sugere tomar as rédeas do futuro com confiança.",
        "invertida": "Falta de planejamento, medo do desconhecido, estagnação, indecisão. Pode indicar hesitação ou oportunidades perdidas."
    },
    "contextos": {
        "amor": "Planejamento de um futuro juntos ou decisões sobre relacionamentos. Invertida, sugere medo de compromisso ou incerteza.",
        "carreira": "Oportunidades de expansão ou novos projetos. Invertida, alerta para falta de visão ou resistência à mudança profissional.",
        "saude": "Planejamento de hábitos saudáveis para energia futura. Invertida, pode indicar desmotivação ou negligência com o corpo.",
        "espiritualidade": "Visão espiritual de novos caminhos. Invertida, sugere dúvida ou resistência ao crescimento espiritual."
    },
    "curiosidade": "O Dois de Paus é associado a Marte em Áries, refletindo energia ousada e a coragem de planejar grandes feitos."
}' WHERE id = 24;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Três de Paus: A Expansão do Horizonte",
    "introducao": "O Três de Paus simboliza progresso, expansão e visão de longo alcance. Representa o momento em que os planos começam a se materializar, trazendo confiança e a expectativa de novas oportunidades, como um navegante que vê terra à frente.",
    "simbologia": "No Rider-Waite, um homem observa navios no mar, segurando um bastão, com dois outros fincados, simbolizando conquistas iniciais. O mar dourado reflete oportunidades, e as montanhas sugerem desafios superados.",
    "significados": {
        "direita": "Progresso, expansão, visão, oportunidades, confiança. O Três de Paus sugere que seus esforços estão gerando resultados.",
        "invertida": "Atrasos, frustração, falta de visão, oportunidades perdidas. Pode indicar obstáculos ou falta de progresso."
    },
    "contextos": {
        "amor": "Crescimento em relacionamentos ou novas conexões promissoras. Invertida, sugere estagnação ou expectativas não atendidas.",
        "carreira": "Sucesso inicial em projetos ou expansão profissional. Invertida, alerta para atrasos ou falta de planejamento.",
        "saude": "Melhoria da energia com esforços consistentes. Invertida, pode indicar frustração ou necessidade de ajustar rotinas.",
        "espiritualidade": "Expansão espiritual através de novas experiências. Invertida, sugere bloqueios ou resistência ao crescimento."
    },
    "curiosidade": "O Três de Paus é associado ao Sol em Áries, combinando vitalidade e liderança para impulsionar o progresso."
}' WHERE id = 25;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Quatro de Paus: A Celebração da Estabilidade",
    "introducao": "O Quatro de Paus simboliza celebração, harmonia e estabilidade conquistada. Representa momentos de alegria compartilhada, como uma festa que marca conquistas ou laços fortalecidos, trazendo um senso de comunidade e segurança.",
    "simbologia": "No Rider-Waite, duas figuras celebram sob uma guirlanda de quatro bastões, simbolizando alegria e união. O castelo ao fundo reflete estabilidade, e as flores sugerem abundância e festividade.",
    "significados": {
        "direita": "Celebração, harmonia, estabilidade, comunidade, conquistas. O Quatro de Paus convida a comemorar sucessos com os outros.",
        "invertida": "Desarmonia, instabilidade, celebração adiada, conflitos. Pode indicar tensões em grupos ou falta de reconhecimento."
    },
    "contextos": {
        "amor": "Celebrações em relacionamentos, como noivados ou momentos felizes. Invertida, sugere conflitos ou instabilidade afetiva.",
        "carreira": "Reconhecimento profissional ou sucesso em equipe. Invertida, alerta para tensões no trabalho ou atrasos em conquistas.",
        "saude": "Bem-estar promovido por alegria e estabilidade. Invertida, pode indicar estresse por desarmonia social.",
        "espiritualidade": "Conexão espiritual através da comunidade. Invertida, sugere isolamento ou dificuldade em compartilhar crenças."
    },
    "curiosidade": "O Quatro de Paus é associado a Vênus em Áries, refletindo a combinação de paixão e harmonia em celebrações."
}' WHERE id = 26;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cinco de Paus: O Conflito da Competição",
    "introducao": "O Cinco de Paus simboliza competição, conflito e luta por afirmação. Representa um momento de tensões ou desafios onde diferentes perspectivas colidem, sugerindo a necessidade de colaboração ou clareza para superar o caos.",
    "simbologia": "No Rider-Waite, cinco homens brandem bastões em direções opostas, simbolizando conflito desordenado. O cenário dinâmico reflete energia caótica, mas a ausência de ferimentos sugere que a luta é mais simbólica que destrutiva.",
    "significados": {
        "direita": "Competição, conflito, desafios, tensão, diversidade. O Cinco de Paus pede para canalizar a energia em colaboração ou clareza.",
        "invertida": "Resolução de conflitos, harmonia, cooperação, foco. Pode indicar superação de tensões ou trabalho em equipe."
    },
    "contextos": {
        "amor": "Discussões ou competição em relacionamentos. Invertida, sugere reconciliação ou maior entendimento mútuo.",
        "carreira": "Rivalidades ou desafios no trabalho. Invertida, indica colaboração ou resolução de disputas profissionais.",
        "saude": "Estresse causado por conflitos ou excesso de energia. Invertida, sugere equilíbrio ou alívio físico e mental.",
        "espiritualidade": "Conflitos internos ou busca por direção. Invertida, indica clareza espiritual ou harmonia interior."
    },
    "curiosidade": "O Cinco de Paus é associado a Saturno em Leão, refletindo tensões criativas que testam a liderança e a expressão."
}' WHERE id = 27;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Seis de Paus: A Vitória Reconhecida",
    "introducao": "O Seis de Paus simboliza vitória, reconhecimento e sucesso público. Representa o momento de receber elogios por esforços realizados, como um herói que retorna triunfante, trazendo confiança e orgulho pelas conquistas.",
    "simbologia": "No Rider-Waite, um cavaleiro coroado com louros cavalga entre uma multidão, segurando um bastão adornado, simbolizando vitória. Os outros bastões erguidos refletem apoio coletivo, e o céu claro sugere clareza.",
    "significados": {
        "direita": "Vitória, reconhecimento, sucesso, confiança, liderança. O Seis de Paus celebra conquistas e o orgulho de realizações.",
        "invertida": "Falta de reconhecimento, fracasso, arrogância, insegurança. Pode indicar atrasos ou vitórias não valorizadas."
    },
    "contextos": {
        "amor": "Reconhecimento mútuo ou sucesso em relacionamentos. Invertida, sugere insegurança ou falta de apreciação afetiva.",
        "carreira": "Promoções ou elogios no trabalho. Invertida, alerta para falta de reconhecimento ou fracassos profissionais.",
        "saude": "Recuperação ou energia elevada após esforços. Invertida, pode indicar exaustão ou necessidade de validação externa.",
        "espiritualidade": "Orgulho espiritual por conquistas interiores. Invertida, sugere dúvida ou busca por validação espiritual."
    },
    "curiosidade": "O Seis de Paus é associado a Júpiter em Leão, refletindo expansão e reconhecimento através da liderança carismática."
}' WHERE id = 28;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Sete de Paus: A Defesa da Posição",
    "introducao": "O Sete de Paus simboliza defesa, resistência e coragem diante de desafios. Representa o momento de manter sua posição contra oposição, lutando por suas convicções com determinação e confiança.",
    "simbologia": "No Rider-Waite, um homem em terreno elevado segura um bastão, enfrentando seis outros, simbolizando resistência. Sua postura defensiva reflete coragem, e o terreno irregular sugere desafios superados.",
    "significados": {
        "direita": "Defesa, coragem, resistência, convicção, perseverança. O Sete de Paus sugere lutar por suas crenças com determinação.",
        "invertida": "Desistência, sobrecarga, insegurança, recuo. Pode indicar cansaço ou dificuldade em manter a posição."
    },
    "contextos": {
        "amor": "Defesa de valores ou luta por um relacionamento. Invertida, sugere desistência ou insegurança afetiva.",
        "carreira": "Resistência a críticas ou competição no trabalho. Invertida, alerta para esgotamento ou recuo profissional.",
        "saude": "Resiliência física ou mental diante de desafios. Invertida, pode indicar exaustão ou necessidade de descanso.",
        "espiritualidade": "Defesa de crenças espirituais contra dúvidas. Invertida, sugere crise de fé ou recuo espiritual."
    },
    "curiosidade": "O Sete de Paus é associado a Marte em Leão, refletindo energia combativa e a coragem de afirmar a própria identidade."
}' WHERE id = 29;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Oito de Paus: A Velocidade do Progresso",
    "introducao": "O Oito de Paus simboliza movimento rápido, progresso e energia direcionada. Representa um momento de ação acelerada, onde eventos se desenrolam com fluidez, trazendo clareza e oportunidades, como flechas disparadas em direção ao alvo.",
    "simbologia": "No Rider-Waite, oito bastões voam pelo céu, simbolizando rapidez e movimento. O rio e a paisagem verde abaixo refletem fluidez, enquanto o céu claro sugere clareza e propósito.",
    "significados": {
        "direita": "Movimento, progresso, rapidez, clareza, oportunidades. O Oito de Paus sugere aproveitar a energia para avançar rapidamente.",
        "invertida": "Atrasos, confusão, energia dispersa, obstáculos. Pode indicar falta de foco ou interrupções no progresso."
    },
    "contextos": {
        "amor": "Desenvolvimentos rápidos ou comunicações apaixonadas. Invertida, sugere mal-entendidos ou atrasos no amor.",
        "carreira": "Avanços rápidos ou novas oportunidades profissionais. Invertida, alerta para confusão ou projetos paralisados.",
        "saude": "Energia elevada, ideal para atividades físicas. Invertida, pode indicar estresse ou necessidade de desacelerar.",
        "espiritualidade": "Revelações espirituais ou progresso rápido. Invertida, sugere confusão ou bloqueios espirituais."
    },
    "curiosidade": "O Oito de Paus é associado a Mercúrio em Sagitário, refletindo comunicação rápida e expansão de horizontes."
}' WHERE id = 30;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Nove de Paus: A Resiliência do Guerreiro",
    "introducao": "O Nove de Paus simboliza resiliência, perseverança e defesa final. Representa o momento de reunir forças após batalhas, mantendo a vigilância e a determinação para superar os últimos desafios, como um guerreiro exausto, mas firme.",
    "simbologia": "No Rider-Waite, um homem ferido segura um bastão, com oito outros ao fundo, simbolizando resistência. Sua expressão vigilante reflete cautela, e o curativo na cabeça sugere batalhas passadas.",
    "significados": {
        "direita": "Resiliência, perseverança, defesa, vigilância, força. O Nove de Paus sugere manter a determinação apesar dos desafios.",
        "invertida": "Esgotamento, desistência, paranoia, fraqueza. Pode indicar cansaço ou dificuldade em continuar lutando."
    },
    "contextos": {
        "amor": "Defesa de um relacionamento ou resiliência emocional. Invertida, sugere exaustão ou desistência afetiva.",
        "carreira": "Perseverança em projetos desafiadores. Invertida, alerta para esgotamento ou abandono de metas profissionais.",
        "saude": "Resistência física ou mental, mas com risco de exaustão. Invertida, pode indicar necessidade de descanso ou recuperação.",
        "espiritualidade": "Fé mantida apesar de desafios espirituais. Invertida, sugere crise de crenças ou cansaço espiritual."
    },
    "curiosidade": "O Nove de Paus é associado à Lua em Sagitário, refletindo intuição e resiliência na busca por expansão."
}' WHERE id = 31;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dez de Paus: O Peso da Responsabilidade",
    "introducao": "O Dez de Paus simboliza sobrecarga, responsabilidade e esforço excessivo. Representa o momento em que o peso das obrigações se torna opressivo, sugerindo a necessidade de delegar ou reavaliar prioridades para encontrar alívio.",
    "simbologia": "No Rider-Waite, um homem carrega dez bastões com dificuldade, caminhando em direção a uma vila, simbolizando esforço e proximidade da meta. O céu claro sugere esperança, mas sua postura reflete exaustão.",
    "significados": {
        "direita": "Sobrecarga, responsabilidade, esforço, dever, perseverança. O Dez de Paus pede para reavaliar o peso que você carrega.",
        "invertida": "Alívio, delegação, liberação, colapso, desistência. Pode indicar soltar fardos ou dificuldade em continuar."
    },
    "contextos": {
        "amor": "Esforço excessivo para manter relacionamentos. Invertida, sugere alívio ou necessidade de compartilhar responsabilidades afetivas.",
        "carreira": "Sobrecarga de trabalho ou projetos. Invertida, indica delegação ou liberação de pressões profissionais.",
        "saude": "Estresse físico ou mental por excesso de responsabilidades. Invertida, sugere descanso ou melhoria no bem-estar.",
        "espiritualidade": "Carga espiritual por excesso de compromissos. Invertida, indica liberdade ou reconexão espiritual."
    },
    "curiosidade": "O Dez de Paus é associado a Saturno em Sagitário, refletindo lições de responsabilidade na busca por expansão."
}' WHERE id = 32;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Valete de Paus: O Mensageiro da Paixão",
    "introducao": "O Valete de Paus representa entusiasmo, criatividade e mensagens inspiradoras. Como uma figura jovem, simboliza o início de uma jornada apaixonada, trazendo energia, curiosidade e a coragem de explorar novas ideias.",
    "simbologia": "No Rider-Waite, um jovem segura um bastão em um deserto, simbolizando potencial criativo. Seu traje com salamandras reflete transformação, e o horizonte aberto sugere aventura e possibilidades.",
    "significados": {
        "direita": "Entusiasmo, criatividade, mensagens, aventura, energia. O Valete de Paus convida a abraçar novas ideias com paixão.",
        "invertida": "Impulsividade, falta de foco, atrasos, imaturidade. Pode indicar energia dispersa ou mensagens mal interpretadas."
    },
    "contextos": {
        "amor": "Paixão inicial ou mensagens românticas. Invertida, sugere impulsividade ou falta de compromisso afetivo.",
        "carreira": "Novas ideias ou oportunidades criativas. Invertida, alerta para falta de direção ou projetos abandonados.",
        "saude": "Energia elevada, ideal para atividades físicas. Invertida, pode indicar exaustão por impulsividade.",
        "espiritualidade": "Exploração espiritual apaixonada. Invertida, sugere confusão ou falta de propósito espiritual."
    },
    "curiosidade": "O Valete de Paus é associado ao elemento Fogo, refletindo sua natureza vibrante e inspiradora."
}' WHERE id = 33;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cavaleiro de Paus: O Guerreiro da Aventura",
    "introducao": "O Cavaleiro de Paus simboliza paixão, aventura e ação impulsiva. Como um cavaleiro ardente, ele avança com energia desenfreada, buscando liberdade e novas experiências, mas alerta para a necessidade de moderação.",
    "simbologia": "No Rider-Waite, um cavaleiro galopa em um cavalo empinado, segurando um bastão, simbolizando ação apaixonada. Salamandras em seu traje refletem transformação, e o deserto ao fundo sugere liberdade e desafios.",
    "significados": {
        "direita": "Paixão, aventura, ação, energia, liberdade. O Cavaleiro de Paus sugere perseguir seus desejos com entusiasmo.",
        "invertida": "Impulsividade, frustração, atrasos, descontrole. Pode indicar ações precipitadas ou falta de planejamento."
    },
    "contextos": {
        "amor": "Romance apaixonado ou busca por aventuras afetivas. Invertida, sugere conflitos por impulsividade ou falta de compromisso.",
        "carreira": "Ações ousadas ou novos projetos criativos. Invertida, alerta para projetos mal planejados ou frustrações profissionais.",
        "saude": "Energia elevada, mas risco de esgotamento. Invertida, pode indicar necessidade de descanso ou lesões por imprudência.",
        "espiritualidade": "Busca espiritual apaixonada por liberdade. Invertida, sugere confusão ou impulsividade espiritual."
    },
    "curiosidade": "O Cavaleiro de Paus reflete a energia de Sagitário, com sua busca por aventura e expansão apaixonada."
}' WHERE id = 34;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rainha de Paus: A Rainha da Vitalidade",
    "introducao": "A Rainha de Paus representa carisma, confiança e energia criativa. Como uma figura vibrante, ela inspira com sua paixão e independência, liderando com calor e coragem, enquanto nutre seus projetos e relacionamentos.",
    "simbologia": "No Rider-Waite, a Rainha segura um bastão e um girassol, simbolizando vitalidade e criatividade. Seu trono com leões reflete força, e o gato preto a seus pés sugere intuição e independência.",
    "significados": {
        "direita": "Carisma, confiança, criatividade, liderança, vitalidade. A Rainha de Paus convida a inspirar e liderar com paixão.",
        "invertida": "Insegurança, ciúmes, manipulação, exaustão. Pode indicar falta de confiança ou energia dominadora."
    },
    "contextos": {
        "amor": "Relações apaixonadas e confiantes. Invertida, sugere ciúmes ou insegurança afetiva.",
        "carreira": "Sucesso através de liderança carismática e criatividade. Invertida, alerta para manipulação ou falta de motivação.",
        "saude": "Vitalidade elevada com foco no bem-estar. Invertida, pode indicar esgotamento ou necessidade de autocuidado.",
        "espiritualidade": "Conexão espiritual vibrante e inspiradora. Invertida, sugere desconexão ou dúvida espiritual."
    },
    "curiosidade": "A Rainha de Paus é associada ao elemento Fogo e ao signo de Leão, refletindo sua natureza carismática e confiante."
}' WHERE id = 35;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rei de Paus: O Mestre da Visão",
    "introducao": "O Rei de Paus simboliza liderança, visão e paixão empreendedora. Como um governante inspirador, ele canaliza sua energia criativa para criar mudanças, liderando com coragem e motivando outros a seguirem seus sonhos.",
    "simbologia": "No Rider-Waite, o Rei está sentado em um trono com salamandras e leões, segurando um bastão, simbolizando poder criativo. O deserto ao fundo reflete desafios superados, e sua coroa sugere autoridade visionária.",
    "significados": {
        "direita": "Liderança, visão, paixão, empreendedorismo, inspiração. O Rei de Paus sugere liderar com coragem e motivar os outros.",
        "invertida": "Autoritarismo, impulsividade, falta de visão, insegurança. Pode indicar liderança fraca ou projetos mal direcionados."
    },
    "contextos": {
        "amor": "Relações lideradas por paixão e respeito mútuo. Invertida, sugere dominação ou falta de conexão emocional.",
        "carreira": "Sucesso através de liderança visionária. Invertida, alerta para autoritarismo ou projetos fracassados.",
        "saude": "Energia elevada com foco em liderança física. Invertida, pode indicar exaustão ou necessidade de moderação.",
        "espiritualidade": "Liderança espiritual inspiradora. Invertida, sugere dúvida ou falta de direção espiritual."
    },
    "curiosidade": "O Rei de Paus é associado ao elemento Fogo e ao signo de Áries, refletindo sua natureza empreendedora e visionária."
}' WHERE id = 36;

-- Naipe de Copas
UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Ás de Copas: A Fonte do Coração",
    "introducao": "O Ás de Copas, a primeira carta do naipe de Copas, simboliza o início de uma jornada emocional, cheia de amor, intuição e conexão espiritual. Representa a abertura do coração, um momento de inspiração divina onde novos sentimentos e possibilidades afetivas emergem como uma fonte cristalina.",
    "simbologia": "No baralho Rider-Waite, uma mão divina emerge das nuvens segurando um cálice dourado que transborda água, simbolizando abundância emocional. Uma pomba branca mergulha no cálice, representando paz e espiritualidade, enquanto flores de lótus abaixo indicam pureza e crescimento interior.",
    "significados": {
        "direita": "Amor, intuição, novos começos emocionais, inspiração, conexão espiritual. O Ás de Copas convida a abraçar sentimentos profundos e confiar na voz do coração.",
        "invertida": "Bloqueio emocional, desconexão, amor não correspondido, repressão de sentimentos. Pode indicar dificuldade em expressar ou receber afeto."
    },
    "contextos": {
        "amor": "Um novo romance ou renovação emocional em relacionamentos existentes. Invertida, sugere mágoas ou dificuldade em se abrir para o amor.",
        "carreira": "Inspiração criativa ou projetos guiados pela paixão. Invertida, indica falta de motivação ou desinteresse no trabalho.",
        "saude": "Foco no bem-estar emocional, com práticas como meditação. Invertida, alerta para estresse ou repressão emocional afetando a saúde.",
        "espiritualidade": "Despertar espiritual e conexão com a intuição. Invertida, sugere desconexão do eu interior ou dúvidas espirituais."
    },
    "curiosidade": "O Ás de Copas é associado ao elemento Água, que rege as emoções, a intuição e a fluidez, reforçando sua energia de abertura e conexão emocional."
}' WHERE id = 37;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dois de Copas: A União dos Corações",
    "introducao": "O Dois de Copas representa harmonia, parceria e conexão emocional profunda. Esta carta simboliza a união de duas almas, seja em amor, amizade ou colaboração, marcada por respeito mútuo e equilíbrio afetivo.",
    "simbologia": "No Rider-Waite, um homem e uma mulher trocam cálices, simbolizando troca emocional. Um caduceu com asas e duas serpentes acima deles representa cura e equilíbrio, enquanto o leão alado sugere paixão e proteção espiritual.",
    "significados": {
        "direita": "Amor mútuo, parceria, harmonia, colaboração, conexão emocional. O Dois de Copas sugere uma relação equilibrada e significativa.",
        "invertida": "Desarmonia, desentendimentos, desequilíbrio emocional, separação. Pode indicar conflitos em parcerias ou falta de reciprocidade."
    },
    "contextos": {
        "amor": "Um relacionamento amoroso ou amizade baseada em confiança mútua. Invertida, sugere mal-entendidos ou ruptura emocional.",
        "carreira": "Colaborações bem-sucedidas ou parcerias profissionais. Invertida, alerta para conflitos no trabalho ou falta de alinhamento.",
        "saude": "Equilíbrio emocional promovendo bem-estar. Invertida, pode indicar estresse devido a conflitos relacionais.",
        "espiritualidade": "Conexão espiritual através de parcerias significativas. Invertida, sugere isolamento ou dificuldade em compartilhar crenças."
    },
    "curiosidade": "O Dois de Copas reflete a energia de Vênus em Câncer, combinando amor e nutrição emocional, enfatizando a harmonia nas conexões."
}' WHERE id = 38;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Três de Copas: A Celebração da Amizade",
    "introducao": "O Três de Copas é a carta da alegria compartilhada, da amizade e da celebração. Representa momentos de união, onde a conexão com os outros traz felicidade e renovação emocional, como uma dança de gratidão pela vida.",
    "simbologia": "No Rider-Waite, três mulheres dançam em círculo, erguendo cálices em um brinde, cercadas por frutas e flores, simbolizando abundância e festividade. O cenário vibrante reflete comunidade e harmonia.",
    "significados": {
        "direita": "Alegria, amizade, celebração, comunidade, apoio mútuo. O Três de Copas convida a compartilhar momentos felizes com os outros.",
        "invertida": "Excesso, isolamento, desarmonia social, competição. Pode indicar afastamento de amigos ou celebrações que saem do controle."
    },
    "contextos": {
        "amor": "Apoio emocional de amigos ou celebração em relacionamentos. Invertida, sugere ciúmes ou afastamento social afetando o amor.",
        "carreira": "Sucesso em equipe ou celebração de conquistas no trabalho. Invertida, alerta para competição ou falta de colaboração.",
        "saude": "Bem-estar promovido por conexões sociais. Invertida, pode indicar estresse por isolamento ou excessos em festas.",
        "espiritualidade": "Crescimento espiritual através da comunidade. Invertida, sugere desconexão ou dificuldade em encontrar apoio espiritual."
    },
    "curiosidade": "O Três de Copas é associado a Mercúrio em Câncer, combinando comunicação e emoção, reforçando a alegria da troca social."
}' WHERE id = 39;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Quatro de Copas: A Introspecção Emocional",
    "introducao": "O Quatro de Copas simboliza introspecção, apatia ou reeavaliação emocional. Representa um momento de pausa onde a pessoa reflete sobre seus sentimentos, podendo ignorar oportunidades por estar focada em insatisfações internas.",
    "simbologia": "No Rider-Waite, um jovem está sentado sob uma árvore, olhando para três cálices, enquanto uma mão divina oferece um quarto cálice, simbolizando novas oportunidades. A expressão de desinteresse reflete apatia ou contemplação.",
    "significados": {
        "direita": "Introspecção, apatia, reeavaliação, pausa emocional, insatisfação. O Quatro de Copas sugere refletir antes de agir.",
        "invertida": "Novas oportunidades, renovação emocional, despertar, aceitação. Pode indicar sair da apatia ou reconhecer possibilidades."
    },
    "contextos": {
        "amor": "Reavaliação de relacionamentos ou desinteresse emocional. Invertida, sugere abertura para novas conexões ou renovação no amor.",
        "carreira": "Falta de motivação ou reflexão sobre objetivos. Invertida, indica novas oportunidades profissionais ou entusiasmo renovado.",
        "saude": "Necessidade de cuidar da saúde mental, como meditação. Invertida, sugere motivação para melhorar o bem-estar.",
        "espiritualidade": "Busca interior por significado emocional. Invertida, indica despertar espiritual ou aceitação de novas perspectivas."
    },
    "curiosidade": "O Quatro de Copas é associado à Lua em Câncer, reforçando a introspecção emocional e a conexão com o inconsciente."
}' WHERE id = 40;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cinco de Copas: A Dor da Perda",
    "introducao": "O Cinco de Copas representa luto, perda e foco no que foi perdido. Esta carta convida a reconhecer a dor, mas também a perceber as oportunidades que ainda permanecem, sugerindo que a cura vem ao mudar a perspectiva.",
    "simbologia": "No Rider-Waite, uma figura encapuzada olha para três cálices derramados, simbolizando perda, enquanto dois cálices permanecem de pé atrás, representando esperança. Um rio e uma ponte ao fundo sugerem a possibilidade de seguir em frente.",
    "significados": {
        "direita": "Luto, arrependimento, perda, tristeza, foco no negativo. O Cinco de Copas pede para processar a dor e buscar esperança.",
        "invertida": "Recuperação, aceitação, esperança, seguir em frente, renovação. Pode indicar superação da tristeza ou novas perspectivas."
    },
    "contextos": {
        "amor": "Tristeza por um relacionamento perdido ou decepção amorosa. Invertida, sugere reconciliação ou abertura para novos amores.",
        "carreira": "Frustração com fracassos ou perdas profissionais. Invertida, indica recuperação ou novas oportunidades no trabalho.",
        "saude": "Impacto emocional afetando o bem-estar. Invertida, sugere melhora na saúde mental ou física com uma nova perspectiva.",
        "espiritualidade": "Reflexão sobre perdas espirituais ou de fé. Invertida, indica renovação espiritual ou reconexão com o propósito."
    },
    "curiosidade": "O Cinco de Copas é associado a Marte em Escorpião, refletindo intensidade emocional e a necessidade de transformar a dor."
}' WHERE id = 41;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Seis de Copas: A Nostalgia do Passado",
    "introducao": "O Seis de Copas simboliza nostalgia, memórias e conexões com o passado. Representa a doçura de lembranças felizes, mas também o convite a equilibrar a saudade com a vida presente, trazendo inocência e bondade.",
    "simbologia": "No Rider-Waite, duas crianças trocam cálices cheios de flores em um cenário idílico, simbolizando pureza e memórias felizes. A casa ao fundo sugere segurança e raízes, enquanto as flores representam afeto e renovação.",
    "significados": {
        "direita": "Nostalgia, memórias, bondade, reconexão, inocência. O Seis de Copas convida a revisitar o passado com carinho e generosidade.",
        "invertida": "Apego ao passado, estagnação, idealização, dificuldade de seguir em frente. Pode indicar viver preso a memórias ou evitar o presente."
    },
    "contextos": {
        "amor": "Reconexão com amores do passado ou relações baseadas em afeto puro. Invertida, sugere apego a relacionamentos antigos ou idealização.",
        "carreira": "Projetos inspirados em experiências passadas ou colaboração nostálgica. Invertida, alerta para estagnação ou falta de inovação.",
        "saude": "Bem-estar ligado a práticas familiares ou reconfortantes. Invertida, pode indicar estresse por apego ao passado.",
        "espiritualidade": "Conexão espiritual com raízes ou memórias. Invertida, sugere dificuldade em integrar o passado ao crescimento espiritual."
    },
    "curiosidade": "O Seis de Copas é associado ao Sol em Escorpião, combinando calor emocional com profundidade, evocando memórias transformadoras."
}' WHERE id = 42;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Sete de Copas: As Ilusões do Desejo",
    "introducao": "O Sete de Copas representa escolhas, sonhos e ilusões. Esta carta simboliza um momento de fantasia, onde múltiplas possibilidades parecem atraentes, mas exigem discernimento para evitar se perder em desejos irreais.",
    "simbologia": "No Rider-Waite, uma figura contempla sete cálices flutuantes, cada um contendo símbolos como um castelo, uma serpente ou joias, representando desejos e ilusões. As nuvens sugerem sonhos intangíveis, e a figura reflete indecisão.",
    "significados": {
        "direita": "Sonhos, escolhas, ilusões, imaginação, indecisão. O Sete de Copas pede clareza para distinguir fantasia da realidade.",
        "invertida": "Clareza, foco, realidade, escolhas conscientes, desapego. Pode indicar superar ilusões ou tomar decisões práticas."
    },
    "contextos": {
        "amor": "Fantasias românticas ou dificuldade em escolher um parceiro. Invertida, sugere clareza emocional ou compromisso realista.",
        "carreira": "Múltiplas oportunidades profissionais, mas com risco de distração. Invertida, indica foco em metas concretas.",
        "saude": "Confusão mental ou estresse por excesso de opções. Invertida, sugere equilíbrio e escolhas saudáveis.",
        "espiritualidade": "Exploração de sonhos espirituais, mas com risco de ilusão. Invertida, indica conexão com a verdade espiritual."
    },
    "curiosidade": "O Sete de Copas é associado a Vênus em Escorpião, refletindo desejos intensos e a necessidade de discernimento emocional."
}' WHERE id = 43;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Oito de Copas: A Busca por Algo Maior",
    "introducao": "O Oito de Copas simboliza abandono, introspecção e a busca por um propósito maior. Representa o momento de deixar para trás o que não mais satisfaz, embarcando em uma jornada emocional ou espiritual em busca de significado.",
    "simbologia": "No Rider-Waite, uma figura de capa vermelha deixa oito cálices empilhados, caminhando em direção a montanhas sob uma lua, simbolizando introspecção e transição. O rio reflete fluxo emocional, e a escuridão sugere incerteza.",
    "significados": {
        "direita": "Abandono, busca espiritual, introspecção, transição, desapego. O Oito de Copas sugere deixar o conhecido para buscar propósito.",
        "invertida": "Apego, estagnação, medo de mudança, retorno ao passado. Pode indicar relutância em seguir em frente ou conformismo."
    },
    "contextos": {
        "amor": "Fim de um relacionamento ou busca por conexões mais profundas. Invertida, sugere apego a relações insatisfatórias.",
        "carreira": "Mudança de carreira ou busca por um trabalho com propósito. Invertida, alerta para estagnação ou medo de deixar o conhecido.",
        "saude": "Necessidade de cuidar da saúde mental, como terapia. Invertida, pode indicar negligência emocional ou resistência à mudança.",
        "espiritualidade": "Jornada espiritual profunda em busca de verdade. Invertida, sugere desconexão ou medo de explorar o interior."
    },
    "curiosidade": "O Oito de Copas é associado a Saturno em Peixes, refletindo disciplina na busca por significado espiritual."
}' WHERE id = 44;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Nove de Copas: A Realização dos Desejos",
    "introducao": "O Nove de Copas, conhecido como a \"carta dos desejos\", simboliza satisfação, contentamento e realização emocional. Representa um momento de plenitude, onde os anseios do coração são atendidos, trazendo alegria e gratidão.",
    "simbologia": "No Rider-Waite, um homem sorri sentado diante de nove cálices alinhados, simbolizando abundância emocional. A cortina azul ao fundo sugere proteção, e sua expressão reflete autossatisfação e conquista.",
    "significados": {
        "direita": "Satisfação, realização, gratidão, alegria, desejos atendidos. O Nove de Copas celebra a plenitude emocional e o sucesso.",
        "invertida": "Insatisfação, excessos, desejos não realizados, arrogância. Pode indicar superficialidade ou decepção com conquistas."
    },
    "contextos": {
        "amor": "Relacionamentos felizes e emocionalmente gratificantes. Invertida, sugere insatisfação ou expectativas irreais no amor.",
        "carreira": "Sucesso e reconhecimento no trabalho. Invertida, alerta para insatisfação ou foco em ganhos materiais.",
        "saude": "Bem-estar emocional e físico, com equilíbrio. Invertida, pode indicar excessos ou negligência com a saúde.",
        "espiritualidade": "Gratidão espiritual e conexão com o coração. Invertida, sugere busca por validação externa ou desconexão."
    },
    "curiosidade": "O Nove de Copas é associado a Júpiter em Peixes, refletindo expansão emocional e a realização de sonhos."
}' WHERE id = 45;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dez de Copas: A Harmonia Familiar",
    "introducao": "O Dez de Copas simboliza felicidade, harmonia familiar e realização emocional completa. Representa a plenitude de conexões afetivas, onde amor, paz e união criam um senso de pertencimento e alegria duradoura.",
    "simbologia": "No Rider-Waite, uma família celebra sob um arco-íris com dez cálices, simbolizando realização emocional. O cenário pastoral com um rio e casa reflete estabilidade e felicidade, enquanto o arco-íris indica bênçãos divinas.",
    "significados": {
        "direita": "Felicidade, harmonia familiar, amor duradouro, realização emocional, união. O Dez de Copas celebra conexões profundas e alegria compartilhada.",
        "invertida": "Desarmonia familiar, conflitos, desconexão emocional, ilusões quebradas. Pode indicar tensões em relacionamentos ou ideais não realizados."
    },
    "contextos": {
        "amor": "Relacionamentos amorosos ou familiares harmoniosos. Invertida, sugere conflitos ou desconexão em laços afetivos.",
        "carreira": "Trabalho gratificante com senso de comunidade. Invertida, alerta para tensões no ambiente profissional ou falta de propósito.",
        "saude": "Bem-estar promovido por estabilidade emocional. Invertida, pode indicar estresse por conflitos familiares.",
        "espiritualidade": "Conexão espiritual através de laços afetivos. Invertida, sugere busca por harmonia ou dificuldade em encontrar paz."
    },
    "curiosidade": "O Dez de Copas é associado a Marte em Peixes, combinando paixão e sensibilidade para criar harmonia emocional."
}' WHERE id = 46;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Valete de Copas: O Mensageiro do Coração",
    "introducao": "O Valete de Copas representa sensibilidade, criatividade e mensagens emocionais. Como uma figura jovem e sonhadora, simboliza o início de uma jornada afetiva, trazendo intuição, inspiração e a abertura para novos sentimentos.",
    "simbologia": "No Rider-Waite, um jovem segura um cálice com um peixe, simbolizando imaginação e intuição. Seu traje colorido reflete criatividade, e o cenário aquático ao fundo sugere fluidez emocional e conexão com o inconsciente.",
    "significados": {
        "direita": "Sensibilidade, criatividade, mensagens emocionais, intuição, novos sentimentos. O Valete de Copas convida a explorar emoções com abertura.",
        "invertida": "Imaturidade emocional, manipulação, bloqueio criativo, desilusão. Pode indicar dificuldade em lidar com sentimentos ou ilusões."
    },
    "contextos": {
        "amor": "Novos romances ou mensagens amorosas. Invertida, sugere imaturidade ou mal-entendidos emocionais.",
        "carreira": "Projetos criativos ou oportunidades guiadas pela intuição. Invertida, alerta para falta de foco ou manipulação no trabalho.",
        "saude": "Foco na saúde emocional, como terapia ou expressão artística. Invertida, pode indicar repressão emocional afetando o bem-estar.",
        "espiritualidade": "Exploração intuitiva do caminho espiritual. Invertida, sugere desconexão ou ilusões espirituais."
    },
    "curiosidade": "O Valete de Copas é associado ao elemento Água, reforçando sua natureza sonhadora e emocional, como um portal para a intuição."
}' WHERE id = 47;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cavaleiro de Copas: O Romântico Sonhador",
    "introducao": "O Cavaleiro de Copas simboliza romantismo, idealismo e a busca por conexões emocionais profundas. Como um cavaleiro em missão, ele segue o coração, trazendo paixão, inspiração e o desejo de expressar sentimentos verdadeiros.",
    "simbologia": "No Rider-Waite, um cavaleiro cavalga lentamente, segurando um cálice, simbolizando devoção emocional. Seu cavalo branco reflete pureza, e o rio ao fundo sugere fluxo emocional. As asas em seu elmo indicam inspiração espiritual.",
    "significados": {
        "direita": "Romantismo, idealismo, paixão, inspiração, busca emocional. O Cavaleiro de Copas sugere seguir o coração com autenticidade.",
        "invertida": "Desilusão, manipulação emocional, instabilidade, idealização. Pode indicar promessas não cumpridas ou emoções instáveis."
    },
    "contextos": {
        "amor": "Gestos românticos ou busca por um amor ideal. Invertida, sugere decepções amorosas ou manipulação emocional.",
        "carreira": "Projetos movidos por paixão ou criatividade. Invertida, alerta para falta de praticidade ou promessas vazias no trabalho.",
        "saude": "Bem-estar ligado à expressão emocional. Invertida, pode indicar estresse por idealizações ou instabilidade emocional.",
        "espiritualidade": "Busca espiritual guiada pelo coração. Invertida, sugere ilusões espirituais ou dificuldade em manter o foco."
    },
    "curiosidade": "O Cavaleiro de Copas reflete a energia de Peixes, com sua natureza sonhadora e intuitiva, buscando conexões espirituais e emocionais."
}' WHERE id = 48;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rainha de Copas: A Guardiã das Emoções",
    "introducao": "A Rainha de Copas representa compaixão, intuição e profundidade emocional. Como uma figura materna, ela nutre com empatia e sabedoria, guiando os outros através da compreensão dos sentimentos e da conexão com o coração.",
    "simbologia": "No Rider-Waite, a Rainha segura um cálice elaborado, contemplando-o, simbolizando introspecção emocional. Seu trono à beira-mar reflete fluidez, e a água ao fundo sugere conexão com o inconsciente. Anjos em seu trono indicam proteção espiritual.",
    "significados": {
        "direita": "Compaixão, intuição, empatia, sabedoria emocional, cuidado. A Rainha de Copas convida a ouvir o coração e apoiar os outros.",
        "invertida": "Emoções descontroladas, dependência, manipulação, isolamento. Pode indicar excesso de sensibilidade ou repressão emocional."
    },
    "contextos": {
        "amor": "Relações baseadas em empatia e apoio emocional. Invertida, sugere codependência ou manipulação emocional.",
        "carreira": "Sucesso através da intuição e colaboração compassiva. Invertida, alerta para emoções interferindo no profissionalismo.",
        "saude": "Foco no bem-estar emocional, como terapia ou autocuidado. Invertida, pode indicar esgotamento emocional ou negligência.",
        "espiritualidade": "Conexão profunda com a intuição e o divino. Invertida, sugere desconexão ou dificuldade em confiar na intuição."
    },
    "curiosidade": "A Rainha de Copas é associada ao elemento Água e ao signo de Câncer, reforçando sua natureza nutridora e intuitiva."
}' WHERE id = 49;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rei de Copas: O Mestre das Emoções",
    "introducao": "O Rei de Copas simboliza equilíbrio emocional, sabedoria e liderança compassiva. Como um governante sereno, ele domina seus sentimentos, oferecendo apoio e orientação com empatia, mantendo a estabilidade mesmo em tempestades emocionais.",
    "simbologia": "No Rider-Waite, o Rei está sentado em um trono flutuante sobre o mar, segurando um cálice e um cetro, simbolizando controle emocional e autoridade. O peixe saltando ao fundo reflete intuição, e o navio sugere estabilidade em meio ao caos.",
    "significados": {
        "direita": "Equilíbrio emocional, liderança compassiva, sabedoria, empatia, estabilidade. O Rei de Copas sugere guiar com o coração e a razão.",
        "invertida": "Instabilidade emocional, manipulação, repressão, frieza. Pode indicar dificuldade em expressar sentimentos ou controle excessivo."
    },
    "contextos": {
        "amor": "Relacionamentos estáveis com apoio emocional. Invertida, sugere frieza emocional ou manipulação em relações.",
        "carreira": "Liderança empática e sucesso através da colaboração. Invertida, alerta para instabilidade emocional afetando o trabalho.",
        "saude": "Equilíbrio emocional promovendo saúde. Invertida, pode indicar estresse ou repressão emocional afetando o bem-estar.",
        "espiritualidade": "Sabedoria espiritual guiada pela intuição. Invertida, sugere desconexão ou dificuldade em manter a serenidade espiritual."
    },
    "curiosidade": "O Rei de Copas é associado ao elemento Água e ao signo de Escorpião, combinando profundidade emocional com controle e transformação."
}' WHERE id = 50;

-- Naipe de Espadas
UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Ás de Espadas: A Clareza da Verdade",
    "introducao": "O Ás de Espadas simboliza clareza mental, verdade e poder intelectual. Representa um momento de insight ou revelação, onde a mente corta as ilusões, trazendo foco e determinação para enfrentar desafios com honestidade.",
    "simbologia": "No Rider-Waite, uma mão divina segura uma espada erguida, coroada por uma coroa, simbolizando vitória intelectual. Nuvens escuras ao fundo sugerem desafios, enquanto a paisagem montanhosa reflete conquistas através da clareza.",
    "significados": {
        "direita": "Clareza, verdade, insight, determinação, poder mental. O Ás de Espadas convida a enfrentar a realidade com coragem intelectual.",
        "invertida": "Confusão, manipulação, agressividade mental, bloqueio. Pode indicar falta de clareza ou uso indevido do intelecto."
    },
    "contextos": {
        "amor": "Comunicação honesta ou revelações em relacionamentos. Invertida, sugere mal-entendidos ou manipulação emocional.",
        "carreira": "Novas ideias ou soluções claras para problemas. Invertida, alerta para confusão ou conflitos intelectuais no trabalho.",
        "saude": "Clareza mental promovendo bem-estar. Invertida, pode indicar estresse ou ansiedade por pensamentos confusos.",
        "espiritualidade": "Revelações espirituais através da verdade. Invertida, sugere dúvidas ou manipulação de crenças."
    },
    "curiosidade": "O Ás de Espadas é associado ao elemento Ar, que rege o intelecto, a comunicação e a verdade, reforçando sua energia de clareza."
}' WHERE id = 51;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dois de Espadas: A Escolha Cega",
    "introducao": "O Dois de Espadas simboliza indecisão, equilíbrio tenso e proteção emocional. Representa um momento de impasse, onde a mente luta para tomar uma decisão, muitas vezes bloqueando emoções para manter o controle.",
    "simbologia": "No Rider-Waite, uma mulher vendada segura duas espadas cruzadas, simbolizando equilíbrio e indecisão. O mar calmo e a lua ao fundo sugerem emoções reprimidas, enquanto as rochas refletem obstáculos internos.",
    "significados": {
        "direita": "Indecisão, equilíbrio, proteção emocional, impasse, negação. O Dois de Espadas sugere enfrentar a verdade para superar o bloqueio.",
        "invertida": "Clareza, decisão tomada, revelação, conflito aberto. Pode indicar resolução de impasses ou confronto com emoções."
    },
    "contextos": {
        "amor": "Indecisão em relacionamentos ou repressão de sentimentos. Invertida, sugere comunicação aberta ou resolução de conflitos.",
        "carreira": "Paralisia por medo de decidir ou conflitos evitados. Invertida, indica decisões claras ou confronto no trabalho.",
        "saude": "Estresse mental por indecisão. Invertida, sugere alívio ou necessidade de enfrentar questões emocionais.",
        "espiritualidade": "Busca por clareza espiritual bloqueada por dúvidas. Invertida, indica revelações ou avanço espiritual."
    },
    "curiosidade": "O Dois de Espadas é associado à Lua em Libra, refletindo a tensão entre equilíbrio e indecisão emocional."
}' WHERE id = 52;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Três de Espadas: A Dor da Verdade",
    "introducao": "O Três de Espadas simboliza dor emocional, traição e verdade dolorosa. Representa um momento de sofrimento causado por revelações ou perdas, mas também a oportunidade de cura através da aceitação da realidade.",
    "simbologia": "No Rider-Waite, um coração é perfurado por três espadas sob uma chuva, simbolizando dor e traição. As nuvens escuras refletem tristeza, mas o coração sugere resiliência emocional.",
    "significados": {
        "direita": "Dor emocional, traição, separação, verdade dolorosa, luto. O Três de Espadas pede para processar a dor e buscar cura.",
        "invertida": "Recuperação, perdão, superação, aceitação. Pode indicar alívio da dor ou reconciliação após conflitos."
    },
    "contextos": {
        "amor": "Coração partido ou traição em relacionamentos. Invertida, sugere cura emocional ou reconciliação.",
        "carreira": "Decepções ou conflitos no trabalho. Invertida, indica resolução de problemas ou superação de fracassos.",
        "saude": "Estresse ou depressão afetando o bem-estar. Invertida, sugere melhora na saúde mental ou emocional.",
        "espiritualidade": "Crise espiritual causada por perdas. Invertida, indica renovação ou aceitação espiritual."
    },
    "curiosidade": "O Três de Espadas é associado a Saturno em Libra, refletindo lições difíceis que levam à maturidade emocional."
}' WHERE id = 53;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Quatro de Espadas: O Repouso da Mente",
    "introducao": "O Quatro de Espadas simboliza descanso, recuperação e introspecção. Representa a necessidade de uma pausa para recarregar a mente e o corpo, afastando-se do caos para encontrar clareza e equilíbrio.",
    "simbologia": "No Rider-Waite, um cavaleiro descansa em uma tumba, com três espadas penduradas e uma na horizontal, simbolizando pausa e reflexão. O vitral ao fundo sugere esperança espiritual, e a igreja reflete santuário.",
    "significados": {
        "direita": "Descanso, recuperação, introspecção, pausa, meditação. O Quatro de Espadas sugere retirar-se para encontrar paz.",
        "invertida": "Agitação, exaustão, resistência ao descanso, retorno precipitado. Pode indicar dificuldade em pausar ou estresse acumulado."
    },
    "contextos": {
        "amor": "Pausa em relacionamentos para reflexão. Invertida, sugere conflitos renovados ou retorno sem resolução.",
        "carreira": "Necessidade de descanso ou reavaliação profissional. Invertida, alerta para esgotamento ou pressão no trabalho.",
        "saude": "Recuperação física ou mental através do repouso. Invertida, pode indicar exaustão ou negligência com a saúde.",
        "espiritualidade": "Meditação e introspecção espiritual. Invertida, sugere agitação mental ou resistência à quietude."
    },
    "curiosidade": "O Quatro de Espadas é associado a Júpiter em Libra, refletindo expansão através do equilíbrio e da pausa."
}' WHERE id = 54;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cinco de Espadas: O Conflito da Vitória",
    "introducao": "O Cinco de Espadas simboliza conflito, vitória a qualquer custo e tensão. Representa situações onde o desejo de vencer pode levar a perdas emocionais ou éticas, sugerindo a necessidade de avaliar o verdadeiro custo das batalhas.",
    "simbologia": "No Rider-Waite, um homem segura três espadas, com duas no chão, enquanto outros se afastam, simbolizando vitória amarga. O céu nublado reflete tensão, e o mar agitado sugere instabilidade emocional.",
    "significados": {
        "direita": "Conflito, vitória vazia, manipulação, tensão, egoísmo. O Cinco de Espadas pede para considerar as consequências de suas ações.",
        "invertida": "Reconciliação, superação de conflitos, arrependimento, paz. Pode indicar resolução de disputas ou aprendizado com erros."
    },
    "contextos": {
        "amor": "Discussões ou manipulação em relacionamentos. Invertida, sugere perdão ou resolução de conflitos amorosos.",
        "carreira": "Competição desleal ou vitórias que custam caro. Invertida, indica colaboração ou superação de tensões no trabalho.",
        "saude": "Estresse mental causado por conflitos. Invertida, sugere alívio ou melhoria na saúde mental.",
        "espiritualidade": "Conflitos internos ou crise de valores. Invertida, indica paz espiritual ou aprendizado ético."
    },
    "curiosidade": "O Cinco de Espadas é associado a Vênus em Aquário, refletindo tensões entre desejos individuais e harmonia social."
}' WHERE id = 55;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Seis de Espadas: A Travessia da Cura",
    "introducao": "O Seis de Espadas simboliza transição, cura e movimento em direção à paz. Representa a jornada de deixar para trás dificuldades, buscando um futuro mais calmo, muitas vezes com apoio ou orientação.",
    "simbologia": "No Rider-Waite, uma figura rema um barco com uma mulher e uma criança, simbolizando fuga de conflitos. As seis espadas no barco refletem bagagem mental, e as águas calmas à frente sugerem esperança.",
    "significados": {
        "direita": "Transição, cura, viagem, alívio, progresso. O Seis de Espadas sugere deixar o passado para encontrar paz.",
        "invertida": "Estagnação, resistência à mudança, bagagem emocional, atrasos. Pode indicar dificuldade em seguir em frente ou apego ao passado."
    },
    "contextos": {
        "amor": "Superar dificuldades em relacionamentos ou buscar novos começos. Invertida, sugere apego ou conflitos não resolvidos.",
        "carreira": "Mudança de emprego ou transição profissional. Invertida, alerta para estagnação ou resistência à mudança no trabalho.",
        "saude": "Recuperação mental ou física com apoio. Invertida, pode indicar lentidão na cura ou resistência a tratamentos.",
        "espiritualidade": "Jornada espiritual em busca de paz interior. Invertida, sugere bloqueios ou dificuldade em deixar crenças antigas."
    },
    "curiosidade": "O Seis de Espadas é associado a Mercúrio em Aquário, refletindo clareza mental na busca por novos horizontes."
}' WHERE id = 56;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Sete de Espadas: A Estratégia da Astúcia",
    "introducao": "O Sete de Espadas simboliza estratégia, engano e independência. Representa a tentativa de alcançar objetivos através de caminhos indiretos, muitas vezes com astúcia, mas alerta para as consequências da desonestidade.",
    "simbologia": "No Rider-Waite, um homem foge com cinco espadas, deixando duas para trás, simbolizando engano ou fuga. O acampamento ao fundo sugere traição, e sua expressão reflete cautela e astúcia.",
    "significados": {
        "direita": "Estratégia, astúcia, independência, engano, cautela. O Sete de Espadas sugere agir com inteligência, mas com ética.",
        "invertida": "Arrependimento, exposição, honestidade, consequências. Pode indicar revelação de mentiras ou retorno à integridade."
    },
    "contextos": {
        "amor": "Falta de transparência ou manipulação em relacionamentos. Invertida, sugere confissão ou resolução de mal-entendidos.",
        "carreira": "Estratégias questionáveis ou competição desleal. Invertida, indica honestidade ou consequências de ações passadas.",
        "saude": "Estresse por segredos ou manipulação. Invertida, sugere alívio através da verdade ou melhoria na saúde mental.",
        "espiritualidade": "Busca espiritual questionável ou autoengano. Invertida, indica clareza ou retorno à verdade espiritual."
    },
    "curiosidade": "O Sete de Espadas é associado à Lua em Aquário, refletindo ilusões mentais e a necessidade de clareza ética."
}' WHERE id = 57;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Oito de Espadas: A Prisão Mental",
    "introducao": "O Oito de Espadas simboliza restrição, medo e prisão mental. Representa um momento de paralisia causado por pensamentos limitantes ou circunstâncias opressivas, mas sugere que a liberdade é possível com clareza e coragem.",
    "simbologia": "No Rider-Waite, uma mulher vendada está cercada por oito espadas, simbolizando restrição. O pântano sob seus pés reflete confusão, mas o castelo ao fundo sugere esperança de libertação.",
    "significados": {
        "direita": "Restrição, medo, prisão mental, vitimização, confusão. O Oito de Espadas pede para enfrentar os medos e buscar clareza.",
        "invertida": "Libertação, clareza, superação, coragem, novos começos. Pode indicar quebra de barreiras mentais ou liberdade."
    },
    "contextos": {
        "amor": "Sentimento de aprisionamento ou medo em relacionamentos. Invertida, sugere liberdade emocional ou resolução de conflitos.",
        "carreira": "Paralisia por insegurança ou opressão no trabalho. Invertida, indica novas oportunidades ou superação de barreiras.",
        "saude": "Ansiedade ou estresse mental afetando o bem-estar. Invertida, sugere alívio ou melhoria na saúde mental.",
        "espiritualidade": "Bloqueios espirituais causados por medos. Invertida, indica despertar ou libertação espiritual."
    },
    "curiosidade": "O Oito de Espadas é associado a Júpiter em Gêmeos, refletindo expansão bloqueada por pensamentos limitantes."
}' WHERE id = 58;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Nove de Espadas: O Peso da Ansiedade",
    "introducao": "O Nove de Espadas simboliza ansiedade, medo e angústia mental. Representa noites de insônia onde a mente é consumida por preocupações, mas sugere que enfrentar esses medos pode levar à cura e ao alívio.",
    "simbologia": "No Rider-Waite, uma figura acorda à noite, cobrindo o rosto, com nove espadas na parede, simbolizando tormento mental. A colcha com rosas e signos sugere esperança sob a dor, e a escuridão reflete isolamento.",
    "significados": {
        "direita": "Ansiedade, medo, insônia, culpa, angústia. O Nove de Espadas pede para enfrentar os medos e buscar apoio.",
        "invertida": "Recuperação, esperança, superação de medos, alívio. Pode indicar melhoria da saúde mental ou apoio recebido."
    },
    "contextos": {
        "amor": "Preocupações ou culpa afetando relacionamentos. Invertida, sugere resolução de conflitos ou alívio emocional.",
        "carreira": "Estresse ou medo de fracasso no trabalho. Invertida, indica superação de ansiedades ou novas perspectivas.",
        "saude": "Ansiedade ou depressão afetando o bem-estar. Invertida, sugere melhoria ou busca por ajuda profissional.",
        "espiritualidade": "Crise espiritual causada por medos. Invertida, indica renovação ou reconexão espiritual."
    },
    "curiosidade": "O Nove de Espadas é associado a Marte em Gêmeos, refletindo conflitos mentais intensos que exigem resolução."
}' WHERE id = 59;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dez de Espadas: O Fim da Dor",
    "introducao": "O Dez de Espadas simboliza o fim de um ciclo doloroso, traição ou colapso mental. Apesar de sua imagem dramática, sugere que o pior já passou, abrindo espaço para recuperação e novos começos.",
    "simbologia": "No Rider-Waite, uma figura está caída com dez espadas nas costas, simbolizando derrota. O céu escuro reflete dor, mas o sol nascente ao fundo sugere esperança e renovação.",
    "significados": {
        "direita": "Fim, traição, colapso, dor, término. O Dez de Espadas indica que o pior passou e a cura pode começar.",
        "invertida": "Recuperação, resiliência, novos começos, esperança. Pode indicar superação de dificuldades ou renovação."
    },
    "contextos": {
        "amor": "Fim de um relacionamento ou traição dolorosa. Invertida, sugere cura emocional ou novos começos amorosos.",
        "carreira": "Colapso profissional ou demissão. Invertida, indica recuperação ou novas oportunidades no trabalho.",
        "saude": "Crise de saúde mental ou física. Invertida, sugere melhoria ou resiliência após desafios.",
        "espiritualidade": "Crise espiritual ou perda de fé. Invertida, indica renovação ou reconexão espiritual."
    },
    "curiosidade": "O Dez de Espadas é associado ao Sol em Gêmeos, refletindo o fim de um ciclo mental com potencial para renovação."
}' WHERE id = 60;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Valete de Espadas: O Mensageiro da Verdade",
    "introducao": "O Valete de Espadas representa curiosidade intelectual, comunicação e busca pela verdade. Como uma figura jovem, simboliza o início de uma jornada mental, trazendo clareza, questionamentos e a coragem de falar o que pensa.",
    "simbologia": "No Rider-Waite, um jovem segura uma espada erguida, pronto para agir, em um cenário ventoso, simbolizando agilidade mental. Nuvens e pássaros ao fundo refletem pensamentos rápidos e liberdade intelectual.",
    "significados": {
        "direita": "Curiosidade, clareza, comunicação, verdade, vigilância. O Valete de Espadas convida a questionar e expressar ideias com coragem.",
        "invertida": "Manipulação, fofoca, impulsividade, confusão. Pode indicar comunicação agressiva ou falta de clareza."
    },
    "contextos": {
        "amor": "Comunicação honesta ou questionamentos em relacionamentos. Invertida, sugere mal-entendidos ou fofocas afetivas.",
        "carreira": "Novas ideias ou mensagens importantes no trabalho. Invertida, alerta para manipulação ou comunicação confusa.",
        "saude": "Clareza mental promovendo bem-estar. Invertida, pode indicar estresse por pensamentos impulsivos.",
        "espiritualidade": "Busca espiritual através da curiosidade intelectual. Invertida, sugere dúvidas ou manipulação de crenças."
    },
    "curiosidade": "O Valete de Espadas é associado ao elemento Ar, refletindo sua natureza inquisitiva e comunicativa."
}' WHERE id = 61;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cavaleiro de Espadas: O Guerreiro da Mente",
    "introducao": "O Cavaleiro de Espadas simboliza ação, determinação e clareza mental. Como um guerreiro impulsivo, ele avança com ideias afiadas, buscando a verdade com coragem, mas alerta para a necessidade de moderação.",
    "simbologia": "No Rider-Waite, um cavaleiro galopa com uma espada erguida, simbolizando ação rápida. O céu tempestuoso e as árvores curvadas refletem intensidade, enquanto seu cavalo veloz sugere urgência.",
    "significados": {
        "direita": "Ação, determinação, clareza, ambição, verdade. O Cavaleiro de Espadas sugere avançar com foco e coragem intelectual.",
        "invertida": "Impulsividade, agressividade, desordem, conflito. Pode indicar ações precipitadas ou comunicação destrutiva."
    },
    "contextos": {
        "amor": "Comunicação direta ou confrontos em relacionamentos. Invertida, sugere discussões impulsivas ou falta de tato.",
        "carreira": "Ações rápidas ou defesa de ideias no trabalho. Invertida, alerta para conflitos ou decisões precipitadas.",
        "saude": "Energia mental elevada, mas risco de estresse. Invertida, pode indicar exaustão por impulsividade.",
        "espiritualidade": "Busca espiritual agressiva pela verdade. Invertida, sugere fanatismo ou confusão espiritual."
    },
    "curiosidade": "O Cavaleiro de Espadas reflete a energia de Aquário, com sua busca por verdade e ação intelectual rápida."
}' WHERE id = 62;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rainha de Espadas: A Guardiã da Verdade",
    "introducao": "A Rainha de Espadas representa clareza, independência e sabedoria intelectual. Como uma figura perspicaz, ela corta ilusões com honestidade, oferecendo orientação através de sua mente afiada e coração experiente, equilibrando razão e emoção com precisão.",
    "simbologia": "No Rider-Waite, a Rainha segura uma espada erguida, sentada em um trono com nuvens, simbolizando clareza mental. Borboletas em seu trono refletem transformação, o pássaro voando sugere liberdade intelectual, e o vento ao fundo indica agilidade de pensamento.",
    "significados": {
        "direita": "Clareza, independência, honestidade, sabedoria, discernimento. A Rainha de Espadas convida a enfrentar a verdade com coragem e autenticidade.",
        "invertida": "Frialdade, crítica excessiva, manipulação, isolamento. Pode indicar rigidez emocional ou dificuldade em conectar-se com os outros."
    },
    "contextos": {
        "amor": "Relações baseadas em honestidade e independência. Invertida, sugere frieza emocional ou críticas destrutivas no relacionamento.",
        "carreira": "Sucesso através da clareza e liderança intelectual. Invertida, alerta para manipulação ou isolamento profissional.",
        "saude": "Clareza mental promovendo bem-estar, com foco em decisões racionais. Invertida, pode indicar estresse por excesso de autocrítica.",
        "espiritualidade": "Busca espiritual guiada pela verdade e introspecção. Invertida, sugere desconexão ou rigidez em crenças espirituais."
    },
    "curiosidade": "A Rainha de Espadas é associada ao elemento Ar e ao signo de Libra, refletindo sua busca por equilíbrio intelectual e justiça."
}' WHERE id = 63;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rei de Espadas: O Mestre da Razão",
    "introducao": "O Rei de Espadas simboliza autoridade intelectual, verdade e liderança racional. Como um governante justo, ele domina a mente com disciplina, oferecendo clareza e orientação através de sua habilidade de julgar com imparcialidade e sabedoria.",
    "simbologia": "No Rider-Waite, o Rei está sentado em um trono elevado, segurando uma espada erguida, simbolizando poder mental. Borboletas em seu trono refletem transformação, e o céu claro sugere clareza. Sua postura firme indica controle e justiça.",
    "significados": {
        "direita": "Autoridade, verdade, clareza, liderança racional, imparcialidade. O Rei de Espadas sugere liderar com lógica e integridade.",
        "invertida": "Manipulação, autoritarismo, frieza, julgamento severo. Pode indicar abuso de poder intelectual ou falta de empatia."
    },
    "contextos": {
        "amor": "Relações baseadas em comunicação clara e respeito mútuo. Invertida, sugere frieza ou controle excessivo no relacionamento.",
        "carreira": "Sucesso através de liderança intelectual e decisões justas. Invertida, alerta para autoritarismo ou conflitos no trabalho.",
        "saude": "Foco na saúde mental através de disciplina e clareza. Invertida, pode indicar estresse por rigidez ou críticas severas.",
        "espiritualidade": "Sabedoria espiritual alcançada pela razão e verdade. Invertida, sugere dogmatismo ou desconexão espiritual."
    },
    "curiosidade": "O Rei de Espadas é associado ao elemento Ar e ao signo de Aquário, reforçando sua natureza analítica e visão progressista."
}' WHERE id = 64;

-- Naipe de Ouros
UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Ás de Ouros: A Semente da Prosperidade",
    "introducao": "O Ás de Ouros simboliza o início de uma jornada de prosperidade, segurança e abundância material. Representa uma oportunidade nova e fértil, como uma semente plantada em solo rico, pronta para crescer com esforço e dedicação.",
    "simbologia": "No Rider-Waite, uma mão divina emerge das nuvens segurando uma moeda dourada, simbolizando potencial material. O jardim verdejante abaixo, com um arco de rosas, reflete fertilidade, enquanto montanhas ao fundo sugerem desafios a superar.",
    "significados": {
        "direita": "Prosperidade, oportunidade, abundância, segurança, novos começos materiais. O Ás de Ouros convida a investir em novas possibilidades com confiança.",
        "invertida": "Oportunidades perdidas, insegurança financeira, ganância, falta de planejamento. Pode indicar investimentos arriscados ou foco excessivo no material."
    },
    "contextos": {
        "amor": "Estabilidade emocional através de segurança material. Invertida, sugere tensões por questões financeiras ou superficialidade.",
        "carreira": "Novas oportunidades de trabalho ou projetos lucrativos. Invertida, alerta para fracassos financeiros ou falta de planejamento.",
        "saude": "Investimento em saúde física, como dieta ou exercícios. Invertida, pode indicar negligência com o corpo por foco material.",
        "espiritualidade": "Crescimento espiritual através da conexão com a terra. Invertida, sugere desconexão ou materialismo excessivo."
    },
    "curiosidade": "O Ás de Ouros é associado ao elemento Terra, que rege a materialidade, a estabilidade e o crescimento prático."
}' WHERE id = 65;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dois de Ouros: O Equilíbrio das Prioridades",
    "introducao": "O Dois de Ouros representa equilíbrio, adaptabilidade e gestão de recursos. Simboliza a habilidade de lidar com múltiplas responsabilidades, mantendo a flexibilidade diante das mudanças, como um malabarista que dança com o fluxo da vida.",
    "simbologia": "No Rider-Waite, um jovem equilibra duas moedas em um movimento de infinito, simbolizando harmonia e adaptabilidade. O mar agitado ao fundo reflete mudanças, enquanto os navios sugerem navegação através de desafios.",
    "significados": {
        "direita": "Equilíbrio, adaptabilidade, multitarefa, gestão de recursos, flexibilidade. O Dois de Ouros sugere manter o controle em meio à mudança.",
        "invertida": "Desequilíbrio, sobrecarga, má gestão, estresse, indecisão. Pode indicar dificuldade em priorizar ou lidar com responsabilidades."
    },
    "contextos": {
        "amor": "Equilíbrio entre amor e outras responsabilidades. Invertida, sugere tensões por falta de tempo ou atenção no relacionamento.",
        "carreira": "Gestão eficiente de projetos ou finanças. Invertida, alerta para sobrecarga ou má administração no trabalho.",
        "saude": "Equilíbrio entre corpo e mente, como exercícios moderados. Invertida, pode indicar estresse por excesso de compromissos.",
        "espiritualidade": "Harmonia entre o material e o espiritual. Invertida, sugere foco excessivo no material, ignorando o interior."
    },
    "curiosidade": "O Dois de Ouros é associado a Júpiter em Capricórnio, combinando expansão com disciplina, refletindo a dança do equilíbrio."
}' WHERE id = 66;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Três de Ouros: A Arte da Colaboração",
    "introducao": "O Três de Ouros simboliza trabalho em equipe, habilidade e reconhecimento. Representa a construção de algo valioso através da colaboração e do domínio de talentos, como artesãos que criam uma obra-prima juntos.",
    "simbologia": "No Rider-Waite, um artesão trabalha em uma catedral, colaborando com um monge e um arquiteto, simbolizando união de habilidades. As três moedas no arco refletem conquistas materiais, e a catedral sugere legado duradouro.",
    "significados": {
        "direita": "Colaboração, habilidade, reconhecimento, trabalho em equipe, qualidade. O Três de Ouros sugere sucesso através da cooperação.",
        "invertida": "Falta de colaboração, mediocridade, desentendimentos, esforço não reconhecido. Pode indicar conflitos em equipe ou trabalho mal executado."
    },
    "contextos": {
        "amor": "Construção de relacionamentos através do esforço mútuo. Invertida, sugere falta de cooperação ou desentendimentos.",
        "carreira": "Sucesso profissional por trabalho em equipe ou habilidades valorizadas. Invertida, alerta para conflitos ou falta de reconhecimento.",
        "saude": "Melhoria da saúde através de esforços colaborativos, como com profissionais. Invertida, pode indicar negligência ou falta de apoio.",
        "espiritualidade": "Crescimento espiritual através da comunidade ou aprendizado. Invertida, sugere isolamento ou dificuldade em colaborar."
    },
    "curiosidade": "O Três de Ouros é associado a Marte em Capricórnio, refletindo energia direcionada para construir algo duradouro."
}' WHERE id = 67;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Quatro de Ouros: A Segurança do Controle",
    "introducao": "O Quatro de Ouros simboliza segurança, posse e controle material. Representa o desejo de proteger recursos e manter estabilidade, mas também o risco de apego excessivo ou avareza que limita o crescimento.",
    "simbologia": "No Rider-Waite, um homem segura quatro moedas, com uma na cabeça, duas nos pés e uma nos braços, simbolizando posse e controle. A cidade ao fundo sugere estabilidade, mas sua postura rígida reflete apego.",
    "significados": {
        "direita": "Segurança, estabilidade, posse, proteção, conservadorismo. O Quatro de Ouros sugere cuidado com recursos, mas com equilíbrio.",
        "invertida": "Avarice, insegurança, desperdício, desapego excessivo. Pode indicar medo de perder ou má gestão financeira."
    },
    "contextos": {
        "amor": "Estabilidade em relacionamentos, mas com risco de controle. Invertida, sugere insegurança ou possessividade afetiva.",
        "carreira": "Segurança financeira ou proteção de conquistas. Invertida, alerta para perdas ou má administração de recursos.",
        "saude": "Cuidado com a saúde através de rotinas estáveis. Invertida, pode indicar estresse por insegurança financeira.",
        "espiritualidade": "Busca por segurança espiritual através de práticas materiais. Invertida, sugere materialismo ou desconexão espiritual."
    },
    "curiosidade": "O Quatro de Ouros é associado ao Sol em Capricórnio, refletindo o desejo de estabilidade e controle material."
}' WHERE id = 68;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cinco de Ouros: A Luta pela Estabilidade",
    "introducao": "O Cinco de Ouros simboliza dificuldade, pobreza e insegurança material. Representa um momento de escassez ou exclusão, mas também a esperança de encontrar apoio e superar desafios através da resiliência.",
    "simbologia": "No Rider-Waite, duas figuras caminham na neve, passando por uma igreja iluminada, simbolizando esperança em meio à dificuldade. As muletas e trapos refletem fragilidade, enquanto as moedas na janela sugerem ajuda disponível.",
    "significados": {
        "direita": "Escassez, insegurança, exclusão, dificuldades materiais, isolamento. O Cinco de Ouros pede para buscar apoio e manter a esperança.",
        "invertida": "Recuperação, ajuda recebida, renovação, superação de dificuldades. Pode indicar melhora financeira ou apoio inesperado."
    },
    "contextos": {
        "amor": "Inseguranças ou dificuldades afetando relacionamentos. Invertida, sugere apoio mútuo ou renovação emocional.",
        "carreira": "Perdas financeiras ou desemprego. Invertida, indica novas oportunidades ou recuperação profissional.",
        "saude": "Problemas de saúde ligados a estresse ou escassez. Invertida, sugere melhora ou acesso a cuidados médicos.",
        "espiritualidade": "Crise espiritual ou sentimento de abandono. Invertida, indica reconexão ou apoio espiritual encontrado."
    },
    "curiosidade": "O Cinco de Ouros é associado a Mercúrio em Touro, refletindo desafios materiais que testam a resiliência e a busca por estabilidade."
}' WHERE id = 69;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Seis de Ouros: A Generosidade Equilibrada",
    "introducao": "O Seis de Ouros simboliza generosidade, equilíbrio e troca justa. Representa o ato de dar e receber com gratidão, promovendo harmonia material e social, como um ciclo de abundância que beneficia todos.",
    "simbologia": "No Rider-Waite, um homem rico distribui moedas a dois mendigos, segurando uma balança, simbolizando justiça na generosidade. O cenário urbano reflete estrutura social, e as moedas sugerem abundância compartilhada.",
    "significados": {
        "direita": "Generosidade, equilíbrio, troca justa, caridade, prosperidade compartilhada. O Seis de Ouros sugere dar e receber com equilíbrio.",
        "invertida": "Desigualdade, egoísmo, dívidas, dependência. Pode indicar exploração ou desequilíbrio nas trocas materiais."
    },
    "contextos": {
        "amor": "Apoio mútuo em relacionamentos, com generosidade emocional. Invertida, sugere desequilíbrio ou dependência afetiva.",
        "carreira": "Recompensas por esforços ou colaboração generosa. Invertida, alerta para exploração ou falta de reconhecimento.",
        "saude": "Apoio para melhorar a saúde, como ajuda profissional. Invertida, pode indicar negligência ou dependência de outros.",
        "espiritualidade": "Crescimento espiritual através da generosidade. Invertida, sugere materialismo ou dificuldade em compartilhar."
    },
    "curiosidade": "O Seis de Ouros é associado à Lua em Touro, refletindo nutrição material e emocional com equilíbrio."
}' WHERE id = 70;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Sete de Ouros: A Paciência da Colheita",
    "introducao": "O Sete de Ouros simboliza paciência, esforço e avaliação de resultados. Representa um momento de pausa para refletir sobre o progresso, reconhecendo que o crescimento exige tempo e dedicação, como um agricultor que espera a colheita.",
    "simbologia": "No Rider-Waite, um homem observa uma videira com sete moedas, simbolizando frutos do trabalho. Sua expressão pensativa reflete avaliação, e o campo verdejante sugere potencial de crescimento.",
    "significados": {
        "direita": "Paciência, esforço, crescimento lento, avaliação, perseverança. O Sete de Ouros sugere confiar no processo e avaliar resultados.",
        "invertida": "Impaciência, fracasso, estagnação, esforço desperdiçado. Pode indicar falta de progresso ou abandono de projetos."
    },
    "contextos": {
        "amor": "Construção lenta de relacionamentos com paciência. Invertida, sugere frustração ou abandono de esforços afetivos.",
        "carreira": "Progresso gradual no trabalho, com necessidade de avaliação. Invertida, alerta para projetos malsucedidos ou impaciência.",
        "saude": "Melhoria da saúde com esforços consistentes. Invertida, pode indicar negligência ou frustração com resultados lentos.",
        "espiritualidade": "Crescimento espiritual através da paciência. Invertida, sugere desconexão por falta de dedicação."
    },
    "curiosidade": "O Sete de Ouros é associado a Saturno em Touro, refletindo disciplina e paciência na busca por resultados duradouros."
}' WHERE id = 71;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Oito de Ouros: O Ofício do Aperfeiçoamento",
    "introducao": "O Oito de Ouros simboliza dedicação, habilidade e aprendizado contínuo. Representa o esforço meticuloso de um artesão que aperfeiçoa sua arte, focando no trabalho árduo e na busca pela excelência.",
    "simbologia": "No Rider-Waite, um artesão grava moedas com cuidado, simbolizando trabalho detalhado. As moedas penduradas refletem conquistas, e a cidade ao fundo sugere reconhecimento futuro.",
    "significados": {
        "direita": "Dedicação, habilidade, aprendizado, trabalho árduo, perfeccionismo. O Oito de Ouros sugere foco no aprimoramento e esforço consistente.",
        "invertida": "Falta de foco, trabalho malfeito, estagnação, desmotivação. Pode indicar preguiça ou falta de comprometimento."
    },
    "contextos": {
        "amor": "Esforço para melhorar relacionamentos com dedicação. Invertida, sugere negligência ou falta de investimento afetivo.",
        "carreira": "Sucesso através do aprendizado e trabalho árduo. Invertida, alerta para desleixo ou falta de progresso profissional.",
        "saude": "Melhoria da saúde com disciplina, como exercícios regulares. Invertida, pode indicar negligência ou desmotivação.",
        "espiritualidade": "Crescimento espiritual através da prática consistente. Invertida, sugere falta de dedicação ou estagnação espiritual."
    },
    "curiosidade": "O Oito de Ouros é associado ao Sol em Virgem, refletindo perfeccionismo e dedicação ao trabalho bem-feito."
}' WHERE id = 72;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Nove de Ouros: A Abundância Conquistada",
    "introducao": "O Nove de Ouros simboliza prosperidade, independência e prazer material. Representa a realização de esforços passados, trazendo segurança e a capacidade de desfrutar dos frutos do trabalho com gratidão e elegância.",
    "simbologia": "No Rider-Waite, uma mulher elegante está em um jardim luxuoso, segurando um falcão, simbolizando controle e refinamento. As nove moedas na videira refletem riqueza, e o caracol sugere paciência e progresso lento.",
    "significados": {
        "direita": "Prosperidade, independência, prazer, segurança, realização. O Nove de Ouros celebra a abundância conquistada com esforço.",
        "invertida": "Insegurança financeira, dependência, excesso, superficialidade. Pode indicar perdas ou foco em aparências."
    },
    "contextos": {
        "amor": "Relacionamentos estáveis com segurança material. Invertida, sugere dependência ou superficialidade afetiva.",
        "carreira": "Sucesso financeiro e reconhecimento profissional. Invertida, alerta para instabilidade ou gastos excessivos.",
        "saude": "Bem-estar físico com foco no autocuidado. Invertida, pode indicar negligência ou estresse por questões materiais.",
        "espiritualidade": "Gratidão espiritual pela abundância. Invertida, sugere materialismo ou desconexão do propósito espiritual."
    },
    "curiosidade": "O Nove de Ouros é associado a Vênus em Virgem, combinando beleza com praticidade, refletindo prazer na prosperidade."
}' WHERE id = 73;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Dez de Ouros: A Riqueza Duradoura",
    "introducao": "O Dez de Ouros simboliza riqueza, legado e estabilidade familiar. Representa a culminação de esforços materiais, trazendo segurança, tradição e a construção de algo duradouro para as gerações futuras.",
    "simbologia": "No Rider-Waite, uma família se reúne em um cenário próspero, com dez moedas em um arco, simbolizando riqueza herdada. O ancião, a criança e os cães refletem continuidade, enquanto a mansão sugere estabilidade.",
    "significados": {
        "direita": "Riqueza, legado, estabilidade familiar, tradição, segurança. O Dez de Ouros celebra a prosperidade duradoura e a conexão familiar.",
        "invertida": "Instabilidade financeira, conflitos familiares, perda de legado, materialismo. Pode indicar disputas por herança ou desconexão."
    },
    "contextos": {
        "amor": "Relacionamentos estáveis com base em valores familiares. Invertida, sugere tensões por questões financeiras ou tradições.",
        "carreira": "Sucesso financeiro de longo prazo ou negócios familiares. Invertida, alerta para perdas ou conflitos no trabalho.",
        "saude": "Estabilidade física promovida por segurança material. Invertida, pode indicar estresse por insegurança financeira.",
        "espiritualidade": "Conexão espiritual através de tradições familiares. Invertida, sugere materialismo ou perda de valores espirituais."
    },
    "curiosidade": "O Dez de Ouros é associado a Mercúrio em Virgem, refletindo comunicação e planejamento na construção de um legado."
}' WHERE id = 74;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Valete de Ouros: O Aprendiz da Prosperidade",
    "introducao": "O Valete de Ouros representa aprendizado, ambição e oportunidades materiais. Como um jovem curioso, simboliza o início de uma jornada prática, com foco em desenvolver habilidades e construir uma base sólida para o futuro.",
    "simbologia": "No Rider-Waite, um jovem segura uma moeda, contemplando-a em um campo fértil, simbolizando potencial material. Seu traje verde reflete crescimento, e as montanhas ao fundo sugerem desafios a superar.",
    "significados": {
        "direita": "Aprendizado, ambição, oportunidades, diligência, praticidade. O Valete de Ouros convida a investir em crescimento e habilidades.",
        "invertida": "Falta de foco, imaturidade, oportunidades perdidas, preguiça. Pode indicar distração ou má gestão de recursos."
    },
    "contextos": {
        "amor": "Construção de relacionamentos com base em estabilidade. Invertida, sugere imaturidade ou foco excessivo no material.",
        "carreira": "Novas oportunidades de aprendizado ou trabalho. Invertida, alerta para desleixo ou falta de comprometimento profissional.",
        "saude": "Foco em hábitos saudáveis com disciplina. Invertida, pode indicar negligência ou falta de motivação para cuidar do corpo.",
        "espiritualidade": "Crescimento espiritual através de práticas práticas. Invertida, sugere materialismo ou desconexão espiritual."
    },
    "curiosidade": "O Valete de Ouros é associado ao elemento Terra, refletindo sua natureza prática e focada no crescimento material."
}' WHERE id = 75;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Cavaleiro de Ouros: O Guardião do Trabalho",
    "introducao": "O Cavaleiro de Ouros simboliza responsabilidade, trabalho árduo e progresso constante. Como um cavaleiro leal, ele avança com determinação, focado em construir segurança e alcançar metas materiais com paciência.",
    "simbologia": "No Rider-Waite, um cavaleiro está parado em um campo arado, segurando uma moeda, simbolizando dedicação ao trabalho. Seu cavalo robusto reflete estabilidade, e o campo verde sugere fertilidade e esforço recompensado.",
    "significados": {
        "direita": "Responsabilidade, trabalho árduo, progresso, confiabilidade, paciência. O Cavaleiro de Ouros sugere consistência e dedicação às metas.",
        "invertida": "Estagnação, preguiça, monotonia, falta de progresso. Pode indicar resistência à mudança ou foco excessivo na rotina."
    },
    "contextos": {
        "amor": "Relacionamentos estáveis com esforço mútuo. Invertida, sugere monotonia ou negligência afetiva.",
        "carreira": "Sucesso através de trabalho consistente e confiável. Invertida, alerta para estagnação ou falta de inovação.",
        "saude": "Melhoria da saúde com rotinas disciplinadas. Invertida, pode indicar negligência ou exaustão por excesso de trabalho.",
        "espiritualidade": "Crescimento espiritual através da disciplina prática. Invertida, sugere materialismo ou resistência ao crescimento."
    },
    "curiosidade": "O Cavaleiro de Ouros reflete a energia de Virgem, com sua dedicação ao trabalho e atenção aos detalhes."
}' WHERE id = 76;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rainha de Ouros: A Nutridora da Abundância",
    "introducao": "A Rainha de Ouros representa generosidade, segurança e cuidado material. Como uma figura materna, ela nutre com sabedoria prática, criando ambientes de prosperidade e bem-estar através de sua conexão com a terra.",
    "simbologia": "No Rider-Waite, a Rainha segura uma moeda em um jardim exuberante, simbolizando abundância. Seu trono decorado com frutas reflete fertilidade, e o coelho ao seu lado sugere crescimento e intuição.",
    "significados": {
        "direita": "Generosidade, segurança, cuidado, prosperidade, praticidade. A Rainha de Ouros convida a nutrir com sabedoria e criar estabilidade.",
        "invertida": "Insegurança, negligência, materialismo, dependência. Pode indicar descuido com recursos ou foco excessivo no material."
    },
    "contextos": {
        "amor": "Relacionamentos baseados em apoio e estabilidade. Invertida, sugere insegurança ou negligência afetiva.",
        "carreira": "Sucesso através da generosidade e organização. Invertida, alerta para má gestão ou dependência financeira.",
        "saude": "Foco no autocuidado e bem-estar físico. Invertida, pode indicar negligência ou estresse por questões materiais.",
        "espiritualidade": "Conexão espiritual com a terra e a abundância. Invertida, sugere materialismo ou desconexão do propósito."
    },
    "curiosidade": "A Rainha de Ouros é associada ao elemento Terra e ao signo de Capricórnio, refletindo sua natureza prática e nutridora."
}' WHERE id = 77;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Rei de Ouros: O Mestre da Prosperidade",
    "introducao": "O Rei de Ouros simboliza sucesso, autoridade e estabilidade material. Como um governante sábio, ele domina os recursos com confiança, oferecendo segurança e liderança através de sua visão prática e generosidade.",
    "simbologia": "No Rider-Waite, o Rei está sentado em um trono adornado com touros, segurando uma moeda e um cetro, simbolizando riqueza e poder. O jardim luxuoso ao fundo reflete prosperidade, e as vinhas sugerem crescimento contínuo.",
    "significados": {
        "direita": "Sucesso, autoridade, estabilidade, generosidade, visão prática. O Rei de Ouros sugere liderar com sabedoria e construir segurança.",
        "invertida": "Ganância, inflexibilidade, fracasso financeiro, autoritarismo. Pode indicar má gestão ou foco excessivo no material."
    },
    "contextos": {
        "amor": "Relacionamentos estáveis com apoio material. Invertida, sugere controle ou superficialidade afetiva.",
        "carreira": "Sucesso financeiro e liderança respeitada. Invertida, alerta para perdas ou autoritarismo no trabalho.",
        "saude": "Estabilidade física com foco no bem-estar. Invertida, pode indicar negligência ou estresse por ambição.",
        "espiritualidade": "Sabedoria espiritual através da conexão com a terra. Invertida, sugere materialismo ou perda de propósito."
    },
    "curiosidade": "O Rei de Ouros é associado ao elemento Terra e ao signo de Touro, refletindo sua busca por estabilidade e prosperidade."
}' WHERE id = 78;



