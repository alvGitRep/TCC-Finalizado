<?php
require_once "conexao.php";

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
$tipo_usuario = 'comum';

$sql = "INSERT INTO usuarios (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    try {
        $stmt->bind_param("ssss", $nome, $email, $senha, $tipo_usuario);
        $stmt->execute();

        header("Location: ../login.php?registro=sucesso");
        exit();
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) {
            header("Location: ../login.php?erro=email");
            exit();
        } else {
            die("Erro inesperado: " . $e->getMessage());
        }
    }
} else {
    die("Erro ao preparar statement.");
}

$conn->close();
?>