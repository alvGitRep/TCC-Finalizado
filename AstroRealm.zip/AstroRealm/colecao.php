<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['redirecionar_para'] = 'colecao.php';
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

require_once 'php/conexao.php';

$sql = "SELECT * FROM mapas_astrais WHERE usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/colecao.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="icon" type="image/x-icon" href="imagens/ico/argentina1.png">
    <script src="js/cssGeral.js" defer></script>
    <script src="js/colecaoPessoal.js" defer></script>
    <title>AstroRealm: Minha Coleção</title>
</head>
<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo" class="logoMapa"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="index.php">Home</a></li>
                    <li class="menuItem dropdown">
                        <a href="horoscopo.php">Horóscopo</a>
                        <span class="dropdown-toggle">▼</span>
                        <ul class="dropdown-content">
                            <li><a href="horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="signos.php">Os Signos</a></li>
                    <li class="menuItem"><a href="astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="colecao.php" class="underline">Coleção</a></li>
                    <?php if (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'admin'): ?>
                        <li class="menuItem"><a href="admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                    <?php endif; ?>
                </ul>
                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                    <?php endif; ?>
                </div>
            </nav>
        </header>
        <h1 class="titulo-colecao">Minha Coleção</h1>
        <main class="container-colecao">
            <?php
            $backgrounds = glob('imagens/backRandom/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
            sort($backgrounds);
            $totalBackgrounds = count($backgrounds);
            $index = 0;
            while ($mapa = $result->fetch_assoc()):
                $mapa_dados = json_decode($mapa['dados_mapa'], true);
                if ($mapa_dados === null) {
                    echo "<p>Erro ao decodificar JSON: " . htmlspecialchars(json_last_error_msg()) . "</p>";
                    continue;
                }
                $nome = $mapa_dados['data']['name'] ?? '';
                $nascimento = isset($mapa_dados['data']) ?
                    $mapa_dados['data']['day'] . '/' .
                    str_pad($mapa_dados['data']['month'], 2, '0', STR_PAD_LEFT) . '/' .
                    str_pad($mapa_dados['data']['year'], 2, '0', STR_PAD_LEFT) : '';
                $sol = $mapa_dados['data']['sun']['sign'] ?? '';
                $lua = $mapa_dados['data']['moon']['sign'] ?? '';
                $ascendente = $mapa_dados['data']['ascendant']['sign'] ?? '';
                $imagemAtual = $backgrounds[$index % $totalBackgrounds];
                $index++;
            ?>
                <article class="card-mapa">
                    <a href="mapaPessoal.php?id=<?= $mapa['id'] ?>">
                        <div class="imagem-mapa">
                            <img src="<?= htmlspecialchars($imagemAtual) ?>" alt="Mapa Astral">
                        </div>
                        <div class="info-mapa">
                            <h2><?= htmlspecialchars($nome ?? '') ?></h2>
                            <ul>
                                <li><strong>Sol:</strong> <span class="signo" data-sign="<?= htmlspecialchars($sol) ?>"></span></li>
                                <li><strong>Lua:</strong> <span class="signo" data-sign="<?= htmlspecialchars($lua) ?>"></span></li>
                                <li><strong>Ascendente:</strong> <span class="signo" data-sign="<?= htmlspecialchars($ascendente) ?>"></span></li>
                                <li><strong>Nascido em:</strong> <?= htmlspecialchars($nascimento ?? '') ?></li>
                            </ul>
                            <time>Criado em: <?= htmlspecialchars($mapa['data_criacao'] ?? '') ?></time>
                        </div>
                    </a>
                    <button class="btnExcluirMapa" data-mapa-id="<?= $mapa['id'] ?>" onclick="confirmarExclusao(<?= $mapa['id'] ?>)">Excluir</button>
                </article>
            <?php endwhile; ?>
        </main>
    </div>
    <script>
        function confirmarExclusao(mapaId) {
            if (confirm('Tem certeza que deseja excluir este mapa astral?')) {
                window.location.href = 'php/excluir_mapa.php?id=' + mapaId;
            }
        }
    </script>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>