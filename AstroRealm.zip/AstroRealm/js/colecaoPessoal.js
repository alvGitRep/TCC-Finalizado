const nomesSignos = {
    'Ari': 'Áries',
    'Tau': 'Touro',
    'Gem': 'Gêmeos',
    'Can': 'Câncer',
    'Leo': 'Leão',
    'Vir': 'Virgem',
    'Lib': 'Libra',
    'Sco': 'Escorpião',
    'Sag': 'Sagitário',
    'Cap': 'Capricórnio',
    'Aqu': 'Aquário',
    'Pis': 'Peixes'
};

document.querySelectorAll('.signo').forEach(el => {
    const abrev = el.dataset.sign;
    el.textContent = nomesSignos[abrev] || abrev || '—';
});

const simbolosSignos = {
    '♈️': '♈︎',
    '♉️': '♉︎',
    '♊️': '♊︎',
    '♋️': '♋︎',
    '♌️': '♌︎',
    '♍️': '♍︎',
    '♎️': '♎︎',
    '♏️': '♏︎',
    '♐️': '♐︎',
    '♑️': '♑︎',
    '♒️': '♒︎',
    '♓️': '♓︎'
};

document.querySelectorAll('#fotoPerfil, .simboloTop, #ico, #signoPlanetaSimbolo').forEach(el => {
    const emoji = el.textContent.trim();
    el.textContent = simbolosSignos[emoji] || emoji;
});

const nomesPlanetas = {
    Sun: "Sol",
    Moon: "Lua",
    Mercury: "Mercúrio",
    Venus: "Vênus",
    Mars: "Marte",
    Jupiter: "Júpiter",
    Saturn: "Saturno",
    Uranus: "Urano",
    Neptune: "Netuno",
    Pluto: "Plutão",
    Mean_North_Node: "Nodo Norte",
    Mean_Node: "Nodo Norte",
    Mean_South_Node: "Nodo Sul",
    Chiron: "Quíron",
    Ascendant: "Ascendente",
    MC: "Meio do Céu", "Part of Fortune": "Parte da Fortuna",
    Lilith: "Lilith",
    Mean_Lilith: "Lilith Média",
    Vertex: "Vértice",
    Ceres: "Ceres",
    Pallas: "Palas",
    Juno: "Juno",
    Vesta: "Vesta",
    Eris: "Éris",
    Sedna: "Sedna"
};

document.querySelectorAll('.aspecto').forEach(el => {
    const strongs = el.querySelectorAll('strong');
    strongs.forEach(strong => {
        const nome = strong.textContent.trim();
        if (nomesPlanetas[nome]) {
            strong.textContent = nomesPlanetas[nome];
        }
    });
});


document.querySelectorAll('.nomePlaneta strong').forEach(el => {
    const nome = el.textContent.trim();
    if (nomesPlanetas[nome]) {
        el.textContent = nomesPlanetas[nome];
    }
});

const aspectosTraduzidos = {
    conjunction: "Conjunção",
    opposition: "Oposição",
    trine: "Trígono",
    square: "Quadratura",
    sextile: "Sextil",
    quincunx: "Quincúncio",
    semisquare: "Semiquadratura",
    sesquiquadrate: "Sesquiquadratura",
    parallel: "Paralelo",
    contraparallel: "Contraparalelo",
    decile: "Décil",
    novile: "Novil",
    undecile: "Undécil",
    duodecile: "Duodécil",
    biquintile: "Biquintil",
    quintile: "Quíntil",
    sesquiquintile: "Sesquiquintil",
    tridecile: "Tridecíl"
};
document.addEventListener('DOMContentLoaded', () => {
    const elementos = document.querySelectorAll('.aspecto-tipo');

    elementos.forEach(el => {
        const original = el.textContent.trim().toLowerCase();
        if (aspectosTraduzidos[original]) {
            el.textContent = aspectosTraduzidos[original];
        }
    });
});

const coresSignos = {
    Ari: "#FF5733",
    Tau: "#9ACD32",
    Gem: "#ADD8E6",
    Can: "#87CEFA",
    Leo: "#FFC300",
    Vir: "#A3C1AD",
    Lib: "#FFB6C1",
    Sco: "#6A0DAD",
    Sag: "#FF8C42",
    Cap: "#8B8680",
    Aqu: "#00CED1",
    Pis: "#B0E0E6"
};

// cor de fundo da div do perfil
const fotoPerfil = document.getElementById('fotoPerfil');
const signo = fotoPerfil.dataset.sign;
if (coresSignos[signo]) {
    fotoPerfil.style.backgroundColor = coresSignos[signo];
}

const mapaDiv = document.getElementById('displayMapa');

console.log(mapaDiv.innerHTML);

document.getElementById('toggleMapa').addEventListener('click', function() {
    // exibição do mapa
    const button = this;

    if (mapaDiv.style.display === 'none') {
        mapaDiv.style.display = 'block';
        button.textContent = 'Ocultar Mapa';
    } else {
        mapaDiv.style.display = 'none';
        button.textContent = 'Mostrar Mapa';
    }
});