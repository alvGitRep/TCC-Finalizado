<?php
session_start();

// Verifica se todas as etapas foram completadas
if (!isset($_SESSION['etapa2'], $_SESSION['etapa3'], $_SESSION['etapa4'], $_SESSION['perdida'])) {
    header("Location: etapa1.php");
    exit();
}

// Junta todos os IDs
$ids = array_merge($_SESSION['etapa2'], $_SESSION['etapa3'], $_SESSION['etapa4'], [$_SESSION['perdida']]);
$ids = implode(',', array_map('intval', $ids));

require_once "../php/conexao.php";

// Busca todas as cartas
$sql = "SELECT * FROM cartas_tarot WHERE id IN ($ids)";
$result = $conn->query($sql);

$cartas = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cartas[$row['id']] = $row;
    }
}
$conn->close();

function exibirCartas($titulo, $ids, $cartas)
{
    echo "<h2>$titulo</h2>";
    echo "<div class='cartas-container'>";
    foreach ($ids as $id) {
        $carta = $cartas[$id];
        echo "<div class='carta'>";
        echo "<img src='../imagens/cartas/" . basename($carta['imagem']) . "' alt='{$carta['nome']}'>";
        echo "<h3>{$carta['nome']}</h3>";
        echo "<p>{$carta['significado']}</p>";
        echo "</div>";
    }
    echo "</div>";
}

function exibirTrincaInterpretada($titulo, $ids, $cartas)
{
    echo "<div class='wrapperResult'>";
    echo "<h2>" . htmlspecialchars($titulo) . "</h2>";
    echo "<div class='cartas-container'>";
    $nomes_cartas = [];
    foreach ($ids as $index => $id) {
        if (!isset($cartas[$id])) continue;
        $carta = $cartas[$id];
        $nomes_cartas[] = htmlspecialchars($carta['nome']);
        echo "<div class='carta'>";
        echo "<a href='asCartas.php?id=" . urlencode($carta['id']) . "'>";
        echo "<img src='../imagens/cartas/" . htmlspecialchars(basename($carta['imagem'])) . "' alt='" . htmlspecialchars($carta['nome']) . "'>";
        echo "</a>";
        echo "<h3>" . htmlspecialchars($carta['nome']) . "</h3>";
        echo "</div>";
    }
    echo "</div>";

    echo "<div id='interpretacoes'>";
    // Exibe os nomes das cartas no topo do bloco de interpretações
    if (!empty($nomes_cartas)) {
        echo "<p class='nomes-cartas'>" . implode(", ", $nomes_cartas) . "</p>";
    }
    foreach ($ids as $inter => $id) {
        if (!isset($cartas[$id])) continue;
        $carta = $cartas[$id];
        $posicao = $inter + 1;
        echo "<div>";
        $campo_interpretacao = "interpretacao_posicao_$posicao";
        if (isset($carta[$campo_interpretacao])) {
            echo "<p>" . htmlspecialchars($carta[$campo_interpretacao]) . "</p>";
        }
        echo "</div>";
    }
    echo "</div>";
    echo "</div>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>AstroRealm: Resultado da Tiragem</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/resultado.css">
    <script src="../js/cssGeral.js" defer></script>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <span class="dropdown-toggle">▼</span>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php" class="underline">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                    <?php if (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'admin'): ?>
                        <li class="menuItem"><a href="../admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                    <?php endif; ?>
                </ul>
                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="../perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="../login.php">Login</a>
                    <?php endif; ?>
                </div>
            </nav>
        </header>
    </div>

    <h1>Resultado Final da Tiragem</h1>
    <div id="topcontainer">
        <?php
        exibirTrincaInterpretada("", $_SESSION['etapa2'], $cartas);
        exibirTrincaInterpretada("", $_SESSION['etapa3'], $cartas);
        exibirTrincaInterpretada("", $_SESSION['etapa4'], $cartas);
        ?>
    </div>

    <h2>Carta Perdida - Aquela que você não escolheu</h2>
    <div class="cartas-container">
        <?php
        if (isset($cartas[$_SESSION['perdida']])) {
            $carta = $cartas[$_SESSION['perdida']];
        ?>
            <div class="carta">
                <a href="asCartas.php?id=<?= urlencode($carta['id']) ?>">
                    <img src="../imagens/cartas/<?= htmlspecialchars(basename($carta['imagem'])) ?>" alt="<?= htmlspecialchars($carta['nome']) ?>">
                </a>
                <h3><?= htmlspecialchars($carta['nome']) ?></h3>
                <span><?= htmlspecialchars($carta['significado']) ?></span>

            </div>

        <?php } ?>

    </div>
    <?php if (!empty($carta['interpretacao_perdida'])): ?>
        <h3 id="interpretacaoPerdida"><?= htmlspecialchars($carta['interpretacao_perdida']) ?></h3>
    <?php else: ?>
        <p>Esta carta representa uma força oculta ou um destino não seguido.</p>
    <?php endif; ?>

    <div id="centralizaBtn">
        <button id="btnNovaTiragem"><a href="etapa1.php">Nova Tiragem</a></button>
    </div>


    <footer>
        <div id="footerContent">
            <div id="footerDivs">
                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios dos signos e muito mais!
                    </p>
                </div>
                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitRep"><img src="../imagens/icones footer/github_1051275.png" title="GitHub" alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin" alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png" alt="">WhatsApp</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>
            </div>
            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
        </div>
    </footer>
    <button id="scrollToTopBtn" title="Voltar ao topo"></button>
</body>

</html>