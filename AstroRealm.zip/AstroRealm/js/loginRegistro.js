const btnLogin = document.getElementById("btnLogin");
const btnRegistro = document.getElementById("btnRegistro");
const formLogin = document.getElementById("formLogin");
const formRegistro = document.getElementById("formRegistro");

btnLogin.addEventListener("click", () => {
    btnLogin.classList.add("active");
    btnRegistro.classList.remove("active");
    formLogin.classList.add("active");
    formRegistro.classList.remove("active");
});

btnRegistro.addEventListener("click", () => {
    btnRegistro.classList.add("active");
    btnLogin.classList.remove("active");
    formRegistro.classList.add("active");
    formLogin.classList.remove("active");
});


formRegistro.addEventListener("submit", function(event) {
    const senha = formRegistro.querySelector('input[name="senha"]').value;
    const confirmaSenha = formRegistro.querySelector('input[name="confirma_senha"]').value;

    if (senha !== confirmaSenha) {
        event.preventDefault(); // impede o envio do formulário
        alert("As senhas não coincidem!");
    }
});