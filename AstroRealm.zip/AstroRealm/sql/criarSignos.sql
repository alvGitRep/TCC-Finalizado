CREATE TABLE signos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_signos VARCHAR(20) NOT NULL UNIQUE,
    signo VARCHAR(20) NOT NULL UNIQUE,
    icone CHAR(5) NOT NULL UNIQUE,
    chamada TEXT NOT NULL,
    elemento VARCHAR(20) NOT NULL,
    cor VARCHAR(50) NOT NULL,
    planeta_regente VARCHAR(20) NOT NULL,
    compatibilidade VARCHAR(100) NOT NULL,
    periodo VARCHAR(100) NOT NULL,
    introducao TEXT NOT NULL,
    mitologia TEXT NOT NULL,
    caracteristicas_positivas TEXT NOT NULL,
    caracteristicas_negativas TEXT NOT NULL,
    relacionamentos TEXT NOT NULL,
    carreira TEXT NOT NULL,
    compatibilidade_texto TEXT NOT NULL,
    influencia_planetaria TEXT NOT NULL,
    dicas TEXT NOT NULL,
    famosos TEXT NOT NULL
);

-- Inserindo os dados de Áries
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Áries',
    'aries',
    '♈︎',
    'O Pioneiro do Zodíaco',
    'Fogo',
    'Vermelho',
    'Marte',
    'Leão, Sagitário',
    '21 de Março à 19 de Abril',
    'Áries, o primeiro signo do zodíaco, é uma força vibrante e indomável. Associado ao elemento <strong>Fogo</strong> e regido por <strong>Marte</strong>, o planeta da ação e da guerra na mitologia romana, os nascidos entre <strong>21 de março e 19 de abril</strong> são movidos por uma energia ardente, coragem inabalável e um desejo incessante de conquistar novos horizontes. Como o pioneiro do zodíaco, Áries simboliza o início, a liderança e a busca por desafios, trazendo consigo uma vitalidade que inspira e motiva.',
    'Na mitologia grega, Áries está associado ao carneiro de ouro com lã de valor inestimável, que foi enviado por Zeus para salvar os irmãos Frixo e Hele. Esse carneiro, mais tarde sacrificado, teve sua lã dourada guardada em um bosque sagrado, protegido por um dragão, e tornou-se o objeto da busca de Jasão e os Argonautas. A história do carneiro reflete a essência de Áries: coragem, determinação e a busca por algo grandioso, mesmo diante de obstáculos aparentemente intransponíveis.',
    '<li><strong>Coragem e ousadia:</strong> Arianos são destemidos, enfrentando desafios com uma bravura que os coloca à frente de qualquer situação. Eles não hesitam em explorar o desconhecido ou em assumir riscos calculados.</li><li><strong>Determinação e iniciativa:</strong> Como líderes naturais, pessoas de Áries tomam a iniciativa e transformam ideias em ações com rapidez e eficiência. Sua energia é contagiante, inspirando outros a seguirem seu exemplo.</li><li><strong>Espontaneidade:</strong> A impulsividade de Áries os leva a viver aventuras emocionantes, muitas vezes agindo por instinto e trazendo frescor às situações rotineiras.</li><li><strong>Entusiasmo e vitalidade:</strong> Com uma paixão ardente pela vida, arianos irradiam otimismo e energia positiva, tornando-se a alma de qualquer ambiente.</li><li><strong>Independência:</strong> Áries valoriza sua liberdade e tem uma forte capacidade de seguir seu próprio caminho, sem depender excessivamente dos outros.</li>',
    '<li><strong>Impulsividade e impaciência:</strong> A pressa em agir pode levar a decisões precipitadas, com consequências que nem sempre são previstas. Arianos podem se frustrar quando as coisas não acontecem no seu ritmo acelerado.</li><li><strong>Temperamento forte:</strong> Quando desafiados ou contrariados, podem reagir de forma explosiva, com acessos de raiva que, embora passageiros, podem ser intensos.</li><li><strong>Egocentrismo:</strong> O foco em seus próprios objetivos pode fazer com que, ocasionalmente, pareçam egoístas ou desconsiderem as necessidades alheias.</li><li><strong>Teimosia:</strong> A determinação de Áries pode se transformar em obstinação, dificultando a aceitação de conselhos ou mudanças de planos.</li>',
    'No amor, arianos são intensos, apaixonados e diretos. Eles mergulham de cabeça nos relacionamentos, buscando parceiros que compartilhem sua energia vibrante e que sejam capazes de acompanhar seu ritmo acelerado. Arianos valorizam a honestidade e a autenticidade, mas podem precisar trabalhar sua paciência para lidar com as nuances emocionais de seus parceiros. Sua natureza leal faz com que sejam protetores e dedicados, mas também exigem reciprocidade e independência na relação.',
    'Áries prospera em ambientes dinâmicos e competitivos. Sua habilidade de liderança e disposição para assumir riscos os torna ideais para papéis como empreendedores, gestores, atletas ou qualquer profissão que exija inovação e coragem. Eles se destacam em situações que demandam decisões rápidas e iniciativa, mas podem precisar aprender a colaborar mais e a planejar a longo prazo para alcançar maior sucesso.',
    'Áries encontra harmonia com signos que compartilham sua energia vibrante, como os signos de <strong>Fogo</strong> (Leão e Sagitário), que alimentam sua chama com entusiasmo mútuo. Signos de <strong>Ar</strong> (Gêmeos, Libra e Aquário) também são compatíveis, pois trazem leveza e estimulam a mente ariana. No entanto, relacionamentos com signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) podem ser desafiadores devido à diferença de ritmo, enquanto os signos de <strong>Água</strong> (Câncer, Escorpião, Peixes) podem exigir mais paciência para lidar com a sensibilidade emocional.',
    'Regido por Marte, Áries carrega a energia do guerreiro. Marte confere aos arianos sua força, determinação e espírito competitivo, mas também pode intensificar sua impulsividade e temperamento. Essa influência planetária os torna movidos por paixão e ação, sempre prontos para liderar e enfrentar desafios. Para equilibrar essa energia, arianos podem se beneficiar de práticas como meditação ou esportes, que canalizam sua vitalidade de forma construtiva.',
    '<li><strong>Gerencie a impulsividade:</strong> Antes de tomar decisões importantes, reserve um momento para refletir e considerar todas as opções.</li><li><strong>Pratique a paciência:</strong> Nem todos acompanham seu ritmo. Aprenda a ouvir e a valorizar diferentes perspectivas.</li><li><strong>Canalize sua energia:</strong> Atividades como esportes, dança ou projetos criativos podem ajudar a direcionar sua vitalidade de forma produtiva.</li><li><strong>Equilibre independência e colaboração:</strong> Trabalhar em equipe pode ampliar seus horizontes e trazer resultados ainda melhores.</li>',
    '<li><strong>Maradona:</strong> Futebolista argentino, conhecido por sua ousadia e liderança em campo.</li><li><strong>Lady Gaga:</strong> Cantora e performer, cuja energia criativa e autenticidade refletem o espírito ariano.</li><li><strong>Robert Downey Jr.:</strong> Ator, famoso por sua carisma e determinação em papéis icônicos como Homem de Ferro.</li><li><strong>Emma Watson:</strong> Atriz e ativista, reconhecida por sua coragem em defender causas sociais.</li><li><strong>Eddie Murphy:</strong> Ator e comediante, cuja energia vibrante domina as telas.</li>'
);

-- Inserindo os dados de Touro
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Touro',
    'taurus',
    '♉︎',
    'O Construtor da Estabilidade',
    'Terra',
    'Verde',
    'Vênus',
    'Virgem, Capricórnio',
    '20 de Abril à 20 de Maio',
    'Touro, o segundo signo do zodíaco, é uma força de estabilidade e determinação. Associado ao elemento <strong>Terra</strong> e regido por <strong>Vênus</strong>, o planeta do amor e da beleza, os nascidos entre <strong>20 de abril e 20 de maio</strong> são conhecidos por sua perseverança, lealdade e apreço pelas coisas boas da vida. Como o signo que representa a solidez, Touro traz uma energia prática e confiável, sempre buscando construir bases firmes para o futuro.',
    'Na mitologia grega, Touro está associado ao mito de Zeus, que se transformou em um magnífico touro branco para conquistar a princesa Europa. Encantada pela beleza e serenidade do animal, Europa montou em seu lombo, e Zeus a levou para Creta, onde se revelou. Essa história reflete a essência de Touro: força, paciência e um charme irresistível que atrai confiança e admiração.',
    '<li><strong>Lealdade e confiabilidade:</strong> Taurinos são extremamente confiáveis, sempre cumprindo promessas e oferecendo apoio inabalável aos que amam.</li><li><strong>Paciência e persistência:</strong> Com uma abordagem metódica, Touro enfrenta desafios com calma e determinação, nunca desistindo de seus objetivos.</li><li><strong>Apreço pela beleza:</strong> Regidos por Vênus, taurinos têm um talento natural para apreciar e criar beleza, seja na arte, na natureza ou em ambientes confortáveis.</li><li><strong>Praticidade:</strong> Sua mentalidade prática os torna excelentes em gerenciar recursos e construir projetos duradouros.</li><li><strong>Sensualidade:</strong> Touro vive a vida com prazer, valorizando experiências sensoriais como boa comida, música e conforto físico.</li>',
    '<li><strong>Teimosia:</strong> A determinação de Touro pode se transformar em obstinação, dificultando mudanças ou a aceitação de novas ideias.</li><li><strong>Possessividade:</strong> Seu apego às pessoas e coisas pode levar a comportamentos possessivos, especialmente em relacionamentos.</li><li><strong>Resistência à mudança:</strong> Taurinos preferem a estabilidade e podem resistir a situações que exijam adaptação rápida.</li><li><strong>Materialismo:</strong> O amor pelo conforto pode, às vezes, levá-los a priorizar bens materiais em detrimento de aspectos emocionais ou espirituais.</li>',
    'No amor, taurinos são românticos, leais e dedicados. Eles buscam relacionamentos estáveis e duradouros, valorizando parceiros que compartilhem seu apreço pela segurança e pelo prazer. Sua natureza afetuosa e sensual faz deles companheiros carinhosos, mas podem precisar trabalhar sua flexibilidade para lidar com mudanças nas dinâmicas relacionais.',
    'Touro se destaca em carreiras que exigem paciência, organização e um toque de criatividade. Sua habilidade de construir e manter projetos os torna ideais para profissões como finanças, agricultura, design, culinária ou artes. Eles prosperam em ambientes onde podem trabalhar em seu próprio ritmo e ver resultados tangíveis de seus esforços.',
    'Touro encontra harmonia com signos de <strong>Terra</strong> (Virgem e Capricórnio), que compartilham sua abordagem prática e focada. Signos de <strong>Água</strong> (Câncer, Escorpião, Peixes) também podem ser compatíveis, pois complementam a estabilidade de Touro com profundidade emocional. No entanto, signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) e <strong>Ar</strong> (Gêmeos, Libra, Aquário) podem gerar conflitos devido à diferença de ritmo e prioridades.',
    'Regido por Vênus, Touro carrega a energia do prazer e da harmonia. Vênus confere aos taurinos um amor pela beleza, conforto e conexões emocionais profundas, mas também pode intensificar sua teimosia e apego. Essa influência planetária os torna movidos por um desejo de estabilidade e bem-estar, mas práticas como meditação ou atividades criativas podem ajudá-los a equilibrar seu lado materialista.',
    '<li><strong>Abra-se à mudança:</strong> Experimente sair da zona de conforto para descobrir novas possibilidades e crescer pessoalmente.</li><li><strong>Gerencie a possessividade:</strong> Confie mais nos outros e pratique o desapego em relacionamentos para evitar tensões.</li><li><strong>Equilibre materialismo e espiritualidade:</strong> Explore atividades como yoga ou escrita para conectar-se com seu lado interior.</li><li><strong>Valorize a flexibilidade:</strong> Pequenos ajustes em sua rotina podem trazer benefícios inesperados.</li>',
    '<li><strong>George Clooney:</strong> Ator e produtor, conhecido por seu charme e dedicação à carreira e causas humanitárias.</li><li><strong>Adele:</strong> Cantora, cuja voz emotiva e autenticidade refletem a sensualidade taurina.</li><li><strong>David Beckham:</strong> Ex-futebolista, reconhecido por sua disciplina e estilo marcante.</li><li><strong>Queen Elizabeth II:</strong> Monarca, símbolo de estabilidade e perseverança.</li><li><strong>Channing Tatum:</strong> Ator, cuja presença carismática e trabalho árduo exemplificam Touro.</li>'
);

-- Inserindo os dados de Gêmeos
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Gêmeos',
    'gemini',
    '♊︎',
    'O Comunicador do Zodíaco',
    'Ar',
    'Amarelo',
    'Mercúrio',
    'Libra, Aquário',
    '21 de Maio à 20 de Junho',
    'Gêmeos, o terceiro signo do zodíaco, é sinônimo de versatilidade e curiosidade. Associado ao elemento <strong>Ar</strong> e regido por <strong>Mercúrio</strong>, o planeta da comunicação, os nascidos entre <strong>21 de maio e 20 de junho</strong> são conhecidos por sua inteligência afiada, charme comunicativo e energia inquieta. Como o signo dos gêmeos, Gêmeos representa dualidade, adaptabilidade e uma constante busca por conhecimento.',
    'Na mitologia grega, Gêmeos é associado aos irmãos Castor e Pólux, conhecidos como os Dióscuros. Apesar de serem gêmeos, apenas Pólux era imortal. Quando Castor morreu, Pólux pediu a Zeus para compartilhar sua imortalidade, e ambos foram transformados na constelação de Gêmeos. Essa história reflete a dualidade e a conexão profunda do signo, que equilibra opostos com harmonia e carisma.',
    '<li><strong>Inteligência e curiosidade:</strong> Geminianos são extremamente curiosos, sempre em busca de novas ideias e conhecimentos.</li><li><strong>Adaptabilidade:</strong> Sua versatilidade permite que se ajustem a diferentes situações e pessoas com facilidade.</li><li><strong>Comunicação:</strong> Regidos por Mercúrio, possuem um talento natural para se expressar, seja falando, escrevendo ou criando.</li><li><strong>Carisma:</strong> Sua energia vibrante e senso de humor os tornam o centro das atenções em qualquer ambiente.</li><li><strong>Inventividade:</strong> Gêmeos é criativo e adora explorar novas formas de pensar e resolver problemas.</li>',
    '<li><strong>Inconstância:</strong> Sua natureza inquieta pode levar a dificuldades em manter o foco ou cumprir compromissos de longo prazo.</li><li><strong>Superficialidade:</strong> O desejo de explorar tudo pode resultar em falta de profundidade em algumas áreas.</li><li><strong>Impulsividade verbal:</strong> Às vezes, falam sem pensar, o que pode causar mal-entendidos.</li><li><strong>Ansiedade:</strong> A mente acelerada de Gêmeos pode levar a momentos de nervosismo ou inquietação.</li>',
    'No amor, geminianos são charmosos, divertidos e buscam parceiros que estimulem sua mente. Eles valorizam a liberdade e a troca intelectual, mas podem precisar trabalhar a consistência emocional para construir relacionamentos mais profundos e estáveis.',
    'Gêmeos brilha em carreiras que envolvem comunicação, criatividade e dinamismo. Profissões como jornalismo, marketing, ensino ou tecnologia são ideais, pois permitem que usem sua inteligência e adaptabilidade. Eles prosperam em ambientes variados, mas devem evitar a dispersão para alcançar o sucesso.',
    'Gêmeos se dá bem com signos de <strong>Ar</strong> (Libra, Aquário), que compartilham sua energia mental e leveza. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) também são compatíveis, pois trazem entusiasmo. No entanto, signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) e <strong>Água</strong> (Câncer, Escorpião, Peixes) podem achar a natureza volátil de Gêmeos desafiadora.',
    'Regido por Mercúrio, Gêmeos carrega a energia da comunicação e da mente ágil. Mercúrio confere aos geminianos curiosidade e eloquência, mas também pode intensificar sua inquietação. Atividades como escrita, leitura ou debates podem ajudar a canalizar essa energia de forma produtiva.',
    '<li><strong>Mantenha o foco:</strong> Estabeleça prioridades claras para evitar a dispersão em projetos ou ideias.</li><li><strong>Pratique a escuta ativa:</strong> Dedique tempo para ouvir os outros, equilibrando sua habilidade de falar.</li><li><strong>Gerencie a ansiedade:</strong> Técnicas como meditação ou exercícios físicos podem acalmar a mente acelerada.</li><li><strong>Aprofunde-se:</strong> Escolha algumas áreas de interesse e explore-as em profundidade para maior realização.</li>',
    '<li><strong>Johnny Depp:</strong> Ator, conhecido por sua versatilidade e carisma excêntrico.</li><li><strong>Angelina Jolie:</strong> Atriz e ativista, cuja inteligência e magnetismo refletem Gêmeos.</li><li><strong>Kanye West:</strong> Rapper e produtor, famoso por sua criatividade e energia inquieta.</li><li><strong>Natalie Portman:</strong> Atriz, reconhecida por sua inteligência e talento multifacetado.</li><li><strong>Paul McCartney:</strong> Músico, cuja habilidade criativa marcou a história.</li>'
);

-- Inserindo os dados de Câncer
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Câncer',
    'cancer',
    '♋︎',
    'O Protetor das Emoções',
    'Água',
    'Prata',
    'Lua',
    'Escorpião, Peixes',
    '21 de Junho à 22 de Julho',
    'Câncer, o quarto signo do zodíaco, é a essência da sensibilidade e proteção. Associado ao elemento <strong>Água</strong> e regido pela <strong>Lua</strong>, os nascidos entre <strong>21 de junho e 22 de julho</strong> são conhecidos por sua empatia, intuição e laços emocionais profundos. Como o signo do caranguejo, Câncer combina força interior com uma natureza acolhedora, sempre buscando segurança e conexão.',
    'Na mitologia grega, Câncer é associado ao caranguejo enviado por Hera para atrapalhar Hércules durante sua batalha contra a Hidra. Apesar de ser esmagado, o caranguejo foi honrado por Hera com um lugar entre as estrelas. Essa história reflete a tenacidade e a lealdade de Câncer, que protege ferozmente aqueles que ama, mesmo diante de grandes desafios.',
    '<li><strong>Empatia:</strong> Cancerianos têm uma habilidade única de entender e compartilhar os sentimentos dos outros.</li><li><strong>Lealdade:</strong> São extremamente dedicados à família e amigos, sempre prontos para apoiar.</li><li><strong>Intuição:</strong> Regidos pela Lua, possuem uma sensibilidade quase sobrenatural para captar emoções e situações.</li><li><strong>Cuidadoso:</strong> Sua natureza protetora os torna cuidadores excepcionais, criando ambientes acolhedores.</li><li><strong>Criatividade:</strong> A imaginação de Câncer floresce em atividades artísticas e emocionais.</li>',
    '<li><strong>Hipersensibilidade:</strong> Cancerianos podem se magoar facilmente e levar críticas para o lado pessoal.</li><li><strong>Humor instável:</strong> Influenciados pela Lua, seus humores podem mudar rapidamente.</li><li><strong>Apego ao passado:</strong> Tendem a se prender a memórias ou ressentimentos, dificultando o desapego.</li><li><strong>Reservados:</strong> Podem se retrair em sua “carapaça” quando se sentem ameaçados.</li>',
    'No amor, cancerianos são românticos e buscam conexões emocionais profundas. Eles valorizam a segurança e a lealdade, mas podem precisar trabalhar sua tendência a se fechar quando feridos. São parceiros carinhosos que priorizam o bem-estar do outro.',
    'Câncer se destaca em carreiras que envolvem cuidado, criatividade ou conexão emocional, como psicologia, ensino, artes ou assistência social. Eles prosperam em ambientes onde podem nutrir os outros, mas devem evitar se sobrecarregar emocionalmente.',
    'Câncer combina bem com signos de <strong>Água</strong> (Escorpião, Peixes), que compartilham sua profundidade emocional. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) oferecem estabilidade. No entanto, signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) e <strong>Ar</strong> (Gêmeos, Libra, Aquário) podem achar a intensidade emocional de Câncer desafiadora.',
    'Regida pela Lua, Câncer é guiado pela intuição e pelas emoções. A Lua confere sensibilidade e empatia, mas também pode intensificar mudanças de humor. Práticas como journaling ou meditação podem ajudar a equilibrar essa energia emocional.',
    '<li><strong>Gerencie emoções:</strong> Use técnicas como respiração profunda para lidar com a hipersensibilidade.</li><li><strong>Pratique o desapego:</strong> Trabalhe para deixar o passado para trás e focar no presente.</li><li><strong>Estabeleça limites:</strong> Evite se sobrecarregar com as emoções dos outros.</li><li><strong>Expresse-se criativamente:</strong> Use a arte ou a escrita para canalizar seus sentimentos.</li>',
    '<li><strong>Tom Hanks:</strong> Ator, conhecido por sua empatia e papéis emocionantes.</li><li><strong>Princess Diana:</strong> Ícone, cuja compaixão tocou o mundo.</li><li><strong>Frida Kahlo:</strong> Artista, cuja obra reflete a profundidade emocional de Câncer.</li><li><strong>Elon Musk:</strong> Empreendedor, com uma visão intuitiva e tenaz.</li><li><strong>Meryl Streep:</strong> Atriz, cuja sensibilidade brilha em suas atuações.</li>'
);

-- Inserindo os dados de Leão
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Leão',
    'leo',
    '♌︎',
    'O Rei do Zodíaco',
    'Fogo',
    'Dourado',
    'Sol',
    'Áries, Sagitário',
    '23 de Julho à 22 de Agosto',
    'Leão, o quinto signo do zodíaco, é a personificação da confiança e do brilho. Associado ao elemento <strong>Fogo</strong> e regido pelo <strong>Sol</strong>, os nascidos entre <strong>23 de julho e 22 de agosto</strong> são conhecidos por sua liderança, carisma e paixão. Como o rei da selva, Leão irradia energia, inspirando os outros com sua presença magnética e determinação.',
    'Na mitologia grega, Leão é associado ao Leão de Neméia, uma fera invencível derrotada por Hércules em seu primeiro trabalho. Sua pele dourada tornou-se um símbolo de força e glória. Essa história reflete a essência de Leão: coragem, majestade e a busca por reconhecimento.',
    '<li><strong>Carisma:</strong> Leão tem uma presença magnética que atrai atenção e admiração.</li><li><strong>Liderança:</strong> São líderes naturais, inspirando outros com sua confiança e visão.</li><li><strong>Generosidade:</strong> Leão é caloroso e gosta de compartilhar sua energia e recursos.</li><li><strong>Criatividade:</strong> Sua paixão alimenta expressões artísticas e ideias inovadoras.</li><li><strong>Confiança:</strong> Acreditam em si mesmos e enfrentam desafios com coragem.</li>',
    '<li><strong>Arrogância:</strong> A confiança de Leão pode, às vezes, ser percebida como arrogância.</li><li><strong>Need for attention:</strong> Podem buscar validação constante, o que pode parecer egocentrismo.</li><li><strong>Teimosia:</strong> Sua determinação pode se transformar em inflexibilidade.</li><li><strong>Dramaticidade:</strong> Tendem a exagerar em suas reações, especialmente sob pressão.</li>',
    'No amor, leoninos são apaixonados, leais e adoram gestos grandiosos. Eles buscam parceiros que admirem sua energia e compartilhem seu entusiasmo, mas precisam equilibrar seu desejo de atenção com a reciprocidade.',
    'Leão se destaca em carreiras que permitem brilhar, como atuação, política, empreendedorismo ou artes cênicas. Eles prosperam em papéis de liderança, mas devem evitar monopolizar o palco para trabalhar bem em equipe.',
    'Leão combina com signos de <strong>Fogo</strong> (Áries, Sagitário), que compartilham sua energia vibrante. Signos de <strong>Ar</strong> (Gêmeos, Libra, Aquário) estimulam sua criatividade. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) e <strong>Água</strong> (Câncer, Escorpião, Peixes) podem achar a intensidade de Leão desafiadora.',
    'Regido pelo Sol, Leão é movido por vitalidade e autoconfiança. O Sol confere brilho e energia, mas também pode amplificar a necessidade de validação. Atividades como teatro ou esportes podem canalizar essa energia de forma positiva.',
    '<li><strong>Equilibre o ego:</strong> Valorize as contribuições dos outros para evitar parecer arrogante.</li><li><strong>Pratique a humildade:</strong> Reconheça que nem sempre precisa estar no centro das atenções.</li><li><strong>Gerencie a dramaticidade:</strong> Mantenha a calma em situações de conflito para evitar exageros.</li><li><strong>Colabore:</strong> Trabalhe em equipe para alcançar resultados ainda maiores.</li>',
    '<li><strong>Madonna:</strong> Cantora, conhecida por sua presença magnética e reinvenção constante.</li><li><strong>Barack Obama:</strong> Ex-presidente, cuja liderança carismática inspirou milhões.</li><li><strong>Jennifer Lopez:</strong> Artista, símbolo de confiança e talento multifacetado.</li><li><strong>Chris Hemsworth:</strong> Ator, cuja energia vibrante brilha em papéis heroicos.</li><li><strong>Meghan Markle:</strong> Atriz e duquesa, conhecida por seu carisma e determinação.</li>'
);

-- Inserindo os dados de Virgem
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Virgem',
    'virgo',
    '♍︎',
    'O Perfeccionista da Ordem',
    'Terra',
    'Marrom',
    'Mercúrio',
    'Touro, Capricórnio',
    '23 de Agosto à 22 de Setembro',
    'Virgem, o sexto signo do zodíaco, é a personificação da precisão e do cuidado. Associado ao elemento <strong>Terra</strong> e regido por <strong>Mercúrio</strong>, os nascidos entre <strong>23 de agosto e 22 de setembro</strong> são conhecidos por sua inteligência analítica, organização e dedicação. Como o signo da virgem, Virgem busca a perfeição em tudo o que faz, com um compromisso inabalável com o serviço e a melhoria.',
    'Na mitologia grega, Virgem é associada a Astreia, a deusa da justiça, que viveu entre os humanos durante a Idade de Ouro, mas ascendeu aos céus quando a humanidade se corrompeu. Sua imagem carrega a essência de Virgem: pureza, justiça e um desejo de melhorar o mundo ao seu redor.',
    '<li><strong>Organização:</strong> Virginianos são mestres em planejar e manter tudo em ordem.</li><li><strong>Inteligência analítica:</strong> Sua mente afiada é excelente para resolver problemas complexos.</li><li><strong>Dedicação:</strong> São trabalhadores incansáveis, sempre buscando a excelência.</li><li><strong>Praticidade:</strong> Sua abordagem terra-a-terra os torna confiáveis e eficientes.</li><li><strong>Empatia:</strong> Apesar de sua natureza analítica, Virginianos são sensíveis às necessidades dos outros.</li>',
    '<li><strong>Perfeccionismo:</strong> A busca pela perfeição pode levar a autocrítica excessiva ou expectativas irreais.</li><li><strong>Crítica excessiva:</strong> Podem ser muito críticos, tanto consigo mesmos quanto com os outros.</li><li><strong>Preocupação excessiva:</strong> Tendem a se preocupar com detalhes, o que pode gerar ansiedade.</li><li><strong>Reservados:</strong> Podem ter dificuldade em se abrir emocionalmente.</li>',
    'No amor, virginianos são leais e atenciosos, mas podem ser reservados. Eles buscam parceiros confiáveis que valorizem sua dedicação, mas precisam aprender a relaxar e expressar suas emoções mais abertamente.',
    'Virgem se destaca em carreiras que exigem precisão, como medicina, contabilidade, pesquisa ou escrita técnica. Eles prosperam em ambientes organizados, mas devem evitar se sobrecarregar com detalhes.',
    'Virgem combina com signos de <strong>Terra</strong> (Touro, Capricórnio), que compartilham sua praticidade. Signos de <strong>Água</strong> (Câncer, Escorpião, Peixes) complementam sua empatia. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) e <strong>Ar</strong> (Gêmeos, Libra, Aquário) podem achar a natureza meticulosa de Virgem restritiva.',
    'Regido por Mercúrio, Virgem combina análise com praticidade. Mercúrio confere inteligência e atenção aos detalhes, mas pode intensificar a tendência ao perfeccionismo. Atividades como organização de projetos ou hobbies criativos podem ajudar a equilibrar essa energia.',
    '<li><strong>Relaxe o perfeccionismo:</strong> Aceite que nem tudo precisa ser perfeito para ser valioso.</li><li><strong>Expresse emoções:</strong> Compartilhe seus sentimentos para fortalecer conexões pessoais.</li><li><strong>Gerencie a ansiedade:</strong> Pratique mindfulness para reduzir preocupações com detalhes.</li><li><strong>Valorize o processo:</strong> Foque no progresso, não apenas no resultado final.</li>',
    '<li><strong>Beyoncé:</strong> Cantora, conhecida por sua dedicação e perfeccionismo artístico.</li><li><strong>Tim Burton:</strong> Diretor, cuja atenção aos detalhes cria mundos únicos.</li><li><strong>Keira Knightley:</strong> Atriz, reconhecida por sua precisão em papéis complexos.</li><li><strong>Zendaya:</strong> Atriz e cantora, cuja inteligência e trabalho árduo brilham.</li><li><strong>Michael Jackson:</strong> Ícone musical, famoso por sua busca pela perfeição.</li>'
);

-- Inserindo os dados de Libra
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Libra',
    'libra',
    '♎︎',
    'O Diplomata do Zodíaco',
    'Ar',
    'Rosa',
    'Vênus',
    'Gêmeos, Aquário',
    '23 de Setembro à 22 de Outubro',
    'Libra, o sétimo signo do zodíaco, é a essência da harmonia e do equilíbrio. Associado ao elemento <strong>Ar</strong> e regido por <strong>Vênus</strong>, os nascidos entre <strong>23 de setembro e 22 de outubro</strong> são conhecidos por sua diplomacia, charme e amor pela beleza. Como o signo da balança, Libra busca justiça e conexões equilibradas em todas as áreas da vida.',
    'Na mitologia grega, Libra está associada à deusa Têmis, que representava a justiça divina e segurava a balança. Sua imagem simboliza a busca de Libra por equilíbrio, imparcialidade e harmonia, valores que guiam suas ações e relacionamentos.',
    '<li><strong>Diplomacia:</strong> Librianos são mestres em mediar conflitos e criar harmonia.</li><li><strong>Charme:</strong> Sua graça natural atrai pessoas com facilidade.</li><li><strong>Senso estético:</strong> Regidos por Vênus, têm um talento para a beleza e a arte.</li><li><strong>Justiça:</strong> Valorizam a imparcialidade e defendem o que é certo.</li><li><strong>Sociabilidade:</strong> Adoram conectar-se com os outros e criar laços significativos.</li>',
    '<li><strong>Indecisão:</strong> A busca por equilíbrio pode levar a dificuldades em tomar decisões.</li><li><strong>Dependência:</strong> Podem priorizar a harmonia a ponto de evitar conflitos necessários.</li><li><strong>Vaidade:</strong> O amor pela beleza pode, às vezes, torná-los superficiais.</li><li><strong>Evitam confronto:</strong> Tendem a fugir de discussões, mesmo quando necessárias.</li>',
    'No amor, librianos são românticos e buscam parcerias equilibradas. Eles valorizam a harmonia e a reciprocidade, mas precisam aprender a enfrentar conflitos diretamente para fortalecer os laços.',
    'Libra se destaca em carreiras que envolvem estética, diplomacia ou justiça, como design, direito, relações públicas ou artes. Eles prosperam em ambientes colaborativos, mas devem evitar a procrastinação causada pela indecisão.',
    'Libra combina com signos de <strong>Ar</strong> (Gêmeos, Aquário), que compartilham sua leveza. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) trazem energia complementar. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) e <strong>Água</strong> (Câncer, Escorpião, Peixes) podem achar a abordagem de Libra muito idealista.',
    'Regido por Vênus, Libra é movido pelo amor e pela beleza. Vênus confere charme e diplomacia, mas pode intensificar a indecisão. Atividades artísticas ou práticas de mediação podem ajudar a equilibrar essa energia.',
    '<li><strong>Tome decisões:</strong> Pratique escolher com confiança, mesmo em situações difíceis.</li><li><strong>Enfrente conflitos:</strong> Aprenda a lidar com discussões de forma construtiva.</li><li><strong>Equilibre as prioridades:</strong> Foque em si mesmo tanto quanto nos outros.</li><li><strong>Explore a criatividade:</strong> Use a arte para expressar sua visão de harmonia.</li>',
    '<li><strong>Kim Kardashian:</strong> Empresária, conhecida por seu senso estético e influência.</li><li><strong>Will Smith:</strong> Ator, cujo carisma e diplomacia conquistam o público.</li><li><strong>Gwyneth Paltrow:</strong> Atriz, com um talento para a beleza e o equilíbrio.</li><li><strong>Eminem:</strong> Rapper, cuja habilidade lírica reflete a mente ágil de Libra.</li><li><strong>Serena Williams:</strong> Tenista, cuja graça e força equilibram o signo.</li>'
);

-- Inserindo os dados de Escorpião
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Escorpião',
    'scorpio',
    '♏︎',
    'O Mestre da Transformação',
    'Água',
    'Preto',
    'Plutão',
    'Câncer, Peixes',
    '23 de Outubro à 21 de Novembro',
    'Escorpião, o oitavo signo do zodíaco, é a personificação da intensidade e da transformação. Associado ao elemento <strong>Água</strong> e regido por <strong>Plutão</strong>, os nascidos entre <strong>23 de outubro e 21 de novembro</strong> são conhecidos por sua paixão, profundidade emocional e determinação. Como o signo do escorpião, Escorpião é misterioso, poderoso e sempre em busca de verdades ocultas.',
    'Na mitologia grega, Escorpião está ligado ao escorpião enviado por Gaia para matar o caçador Órion. Após sua vitória, foi colocado entre as estrelas. Essa história reflete a força, a determinação e a natureza transformadora de Escorpião, que não teme enfrentar desafios profundos.',
    '<li><strong>Paixão:</strong> Escorpianos vivem com intensidade, colocando paixão em tudo o que fazem.</li><li><strong>Determinação:</strong> Sua força de vontade é inabalável, superando qualquer obstáculo.</li><li><strong>Intuição:</strong> Possuem um radar emocional que detecta mentiras e intenções ocultas.</li><li><strong>Lealdade:</strong> São extremamente fiéis àqueles em quem confiam.</li><li><strong>Transformação:</strong> Escorpião abraça mudanças profundas, renascendo mais forte.</li>',
    '<li><strong>Ciúmes:</strong> Sua intensidade pode levar a comportamentos possessivos ou ciumentos.</li><li><strong>Vingança:</strong> Quando feridos, podem guardar ressentimentos e buscar retaliação.</li><li><strong>Reservados:</strong> Tendem a esconder suas emoções, dificultando a conexão inicial.</li><li><strong>Controle:</strong> Podem querer controlar situações ou pessoas para se sentirem seguros.</li>',
    'No amor, escorpianos são apaixonados e intensos, buscando conexões profundas e transformadoras. Eles valorizam a lealdade absoluta, mas precisam aprender a confiar e evitar o ciúme excessivo.',
    'Escorpião se destaca em carreiras que envolvem investigação, psicologia, pesquisa ou transformação, como detetive, terapeuta ou cientista. Eles prosperam em ambientes desafiadores, mas devem evitar manipulações.',
    'Escorpião combina com signos de <strong>Água</strong> (Câncer, Peixes), que entendem sua profundidade. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) oferecem estabilidade. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) e <strong>Ar</strong> (Gêmeos, Libra, Aquário) podem achar a intensidade de Escorpião avassaladora.',
    'Regido por Plutão, Escorpião é movido pela transformação e pelo poder. Plutão confere profundidade e resiliência, mas pode intensificar ciúmes e obsessões. Atividades como terapia ou escrita podem ajudar a canalizar essa energia.',
    '<li><strong>Confie mais:</strong> Trabalhe para superar ciúmes e construir confiança nos relacionamentos.</li><li><strong>Libere ressentimentos:</strong> Pratique o perdão para evitar guardar mágoas.</li><li><strong>Expresse emoções:</strong> Compartilhe seus sentimentos para fortalecer conexões.</li><li><strong>Busque equilíbrio:</strong> Evite extremos emocionais com práticas como meditação.</li>',
    '<li><strong>Leonardo DiCaprio:</strong> Ator, conhecido por sua intensidade e dedicação.</li><li><strong>Scarlett Johansson:</strong> Atriz, cuja profundidade emocional brilha em seus papéis.</li><li><strong>Ryan Reynolds:</strong> Ator, com um charme magnético e determinação.</li><li><strong>Katy Perry:</strong> Cantora, cuja paixão reflete a energia escorpiana.</li><li><strong>Bill Gates:</strong> Empresário, com uma visão transformadora e estratégica.</li>'
);

-- Inserindo os dados de Sagitário
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Sagitário',
    'sagittarius',
    '♐︎',
    'O Aventureiro do Zodíaco',
    'Fogo',
    'Roxo',
    'Júpiter',
    'Áries, Leão',
    '22 de Novembro à 21 de Dezembro',
    'Sagitário, o nono signo do zodíaco, é a essência da aventura e da liberdade. Associado ao elemento <strong>Fogo</strong> e regido por <strong>Júpiter</strong>, os nascidos entre <strong>22 de novembro e 21 de dezembro</strong> são conhecidos por seu otimismo, curiosidade e espírito explorador. Como o arqueiro, Sagitário aponta para horizontes distantes, sempre em busca de novas experiências e sabedoria.',
    'Na mitologia grega, Sagitário é associado ao centauro Quíron, um sábio mentor conhecido por sua bondade e conhecimento. Diferente de outros centauros, Quíron era sábio e gentil, simbolizando a busca de Sagitário por aprendizado e expansão.',
    '<li><strong>Otimismo:</strong> Sagitarianos têm uma visão positiva que inspira os outros.</li><li><strong>Curiosidade:</strong> Sua sede por conhecimento os leva a explorar novas culturas e ideias.</li><li><strong>Independência:</strong> Valorizam a liberdade e seguem seus próprios caminhos.</li><li><strong>Sinceridade:</strong> São honestos e diretos, sempre dizendo o que pensam.</li><li><strong>Aventura:</strong> Amam explorar o mundo, seja fisicamente ou intelectualmente.</li>',
    '<li><strong>Impulsividade:</strong> Sua busca por liberdade pode levar a decisões precipitadas.</li><li><strong>Falta de tato:</strong> Sua sinceridade pode, às vezes, ser brutal ou ofensiva.</li><li><strong>Inquietação:</strong> Podem ter dificuldade em se comprometer com rotinas ou responsabilidades.</li><li><strong>Exagero:</strong> Tendem a prometer mais do que podem cumprir.</li>',
    'No amor, sagitarianos são apaixonados e buscam parceiros que respeitem sua liberdade. Eles valorizam a honestidade e a aventura, mas precisam aprender a equilibrar sua independência com o compromisso.',
    'Sagitário se destaca em carreiras que envolvem exploração, ensino ou criatividade, como viagem, filosofia, jornalismo ou marketing. Eles prosperam em ambientes dinâmicos, mas devem evitar a dispersão.',
    'Sagitário combina com signos de <strong>Fogo</strong> (Áries, Leão), que compartilham sua energia. Signos de <strong>Ar</strong> (Gêmeos, Libra, Aquário) estimulam sua mente. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) e <strong>Água</strong> (Câncer, Escorpião, Peixes) podem achar a inquietação de Sagitário desafiadora.',
    'Regido por Júpiter, Sagitário é movido pela expansão e otimismo. Júpiter confere sorte e curiosidade, mas pode intensificar a impulsividade. Viagens ou estudos podem canalizar essa energia positivamente.',
    '<li><strong>Equilibre a liberdade:</strong> Respeite compromissos sem sacrificar sua independência.</li><li><strong>Pratique a diplomacia:</strong> Seja mais cuidadoso com suas palavras para evitar ofensas.</li><li><strong>Mantenha o foco:</strong> Estabeleça metas claras para canalizar sua energia.</li><li><strong>Aprofunde-se:</strong> Explore temas em profundidade para maior crescimento.</li>',
    '<li><strong>Taylor Swift:</strong> Cantora, conhecida por sua criatividade e autenticidade.</li><li><strong>Brad Pitt:</strong> Ator, com um espírito aventureiro e carismático.</li><li><strong>Miley Cyrus:</strong> Cantora, cuja energia livre reflete Sagitário.</li><li><strong>Steven Spielberg:</strong> Diretor, com uma visão expansiva e criativa.</li><li><strong>Nicki Minaj:</strong> Rapper, conhecida por sua ousadia e energia vibrante.</li>'
);

-- Inserindo os dados de Capricórnio
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Capricórnio',
    'capricorn',
    '♑︎',
    'O Estrategista do Zodíaco',
    'Terra',
    'Cinza',
    'Saturno',
    'Touro, Virgem',
    '22 de Dezembro à 19 de Janeiro',
    'Capricórnio, o décimo signo do zodíaco, é a personificação da ambição e da disciplina. Associado ao elemento <strong>Terra</strong> e regido por <strong>Saturno</strong>, os nascidos entre <strong>22 de dezembro e 19 de janeiro</strong> são conhecidos por sua determinação, responsabilidade e foco no sucesso. Como a cabra montesa, Capricórnio escala os desafios com paciência e estratégia.',
    'Na mitologia grega, Capricórnio é associado a Pricus, a cabra-mar criada por Cronos, que tinha o poder de manipular o tempo. Sua imagem híbrida reflete a habilidade de Capricórnio de combinar praticidade com visão estratégica para alcançar grandes alturas.',
    '<li><strong>Ambição:</strong> Capricornianos têm metas claras e trabalham incansavelmente para alcançá-las.</li><li><strong>Disciplina:</strong> Sua abordagem metódica garante resultados consistentes.</li><li><strong>Responsabilidade:</strong> São confiáveis e assumem suas obrigações com seriedade.</li><li><strong>Paciência:</strong> Avançam com calma, planejando cada passo com cuidado.</li><li><strong>Praticidade:</strong> Sua mentalidade terra-a-terra os torna excelentes estrategistas.</li>',
    '<li><strong>Rigidez:</strong> Podem ser inflexíveis, resistindo a mudanças ou ideias novas.</li><li><strong>Pessimismo:</strong> Sua visão realista pode, às vezes, torná-los excessivamente cautelosos.</li><li><strong>Reservados:</strong> Tendem a esconder emoções, dificultando conexões emocionais.</li><li><strong>Workaholismo:</strong> Podem priorizar o trabalho em detrimento da vida pessoal.</li>',
    'No amor, capricornianos são leais e buscam relacionamentos estáveis. Eles valorizam a confiança e o compromisso, mas precisam aprender a expressar suas emoções para fortalecer os laços.',
    'Capricórnio se destaca em carreiras que exigem planejamento e liderança, como administração, finanças, engenharia ou política. Eles prosperam em ambientes estruturados, mas devem equilibrar trabalho e vida pessoal.',
    'Capricórnio combina com signos de <strong>Terra</strong> (Touro, Virgem), que compartilham sua praticidade. Signos de <strong>Água</strong> (Câncer, Escorpião, Peixes) oferecem equilíbrio emocional. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) e <strong>Ar</strong> (Gêmeos, Libra, Aquário) podem achar a seriedade de Capricórnio restritiva.',
    'Regido por Saturno, Capricórnio é movido pela disciplina e responsabilidade. Saturno confere foco e resiliência, mas pode intensificar a rigidez. Atividades como planejamento ou hobbies relaxantes podem equilibrar essa energia.',
    '<li><strong>Relaxe a rigidez:</strong> Esteja aberto a novas ideias e abordagens.</li><li><strong>Expresse emoções:</strong> Compartilhe seus sentimentos para fortalecer relacionamentos.</li><li><strong>Equilibre trabalho e vida:</strong> Reserve tempo para lazer e conexões pessoais.</li><li><strong>Celebre conquistas:</strong> Reconheça seus sucessos, mesmo os pequenos.</li>',
    '<li><strong>Michelle Obama:</strong> Ex-primeira-dama, conhecida por sua disciplina e impacto.</li><li><strong>Denzel Washington:</strong> Ator, com uma carreira marcada por dedicação.</li><li><strong>Kate Middleton:</strong> Duquesa, símbolo de responsabilidade e elegância.</li><li><strong>Jeff Bezos:</strong> Empresário, cuja ambição transformou o mundo dos negócios.</li><li><strong>Zayn Malik:</strong> Cantor, com uma abordagem focada e estratégica.</li>'
);

-- Inserindo os dados de Aquário
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Aquário',
    'aquarius',
    '♒︎',
    'O Visionário do Futuro',
    'Ar',
    'Azul',
    'Urano',
    'Gêmeos, Libra',
    '20 de Janeiro à 18 de Fevereiro',
    'Aquário, o décimo primeiro signo do zodíaco, é a essência da inovação e da liberdade. Associado ao elemento <strong>Ar</strong> e regido por <strong>Urano</strong>, os nascidos entre <strong>20 de janeiro e 18 de fevereiro</strong> são conhecidos por sua originalidade, visão progressista e espírito humanitário. Como o portador de água, Aquário distribui ideias que transformam o mundo.',
    'Na mitologia grega, Aquário é associado a Ganimedes, o jovem troiano levado por Zeus para servir como copeiro dos deuses. Sua beleza e inteligência fizeram dele um símbolo de renovação, refletindo a essência de Aquário: trazer novas perspectivas ao mundo.',
    '<li><strong>Inovação:</strong> Aquarianos são visionários, sempre pensando fora da caixa.</li><li><strong>Humanitarismo:</strong> Sua preocupação com o bem coletivo os torna defensores de causas sociais.</li><li><strong>Independência:</strong> Valorizam a liberdade e seguem seu próprio caminho.</li><li><strong>Inteligência:</strong> Sua mente ágil é ideal para resolver problemas complexos.</li><li><strong>Originalidade:</strong> Sua autenticidade os destaca em qualquer multidão.</li>',
    '<li><strong>Aloofness:</strong> Podem parecer distantes ou emocionalmente desconectados.</li><li><strong>Teimosia:</strong> Sua visão fixa pode dificultar a aceitação de outras opiniões.</li><li><strong>Imprevisibilidade:</strong> Sua natureza excêntrica pode ser confusa para os outros.</li><li><strong>Rebeldia:</strong> Tendem a desafiar regras sem considerar as consequências.</li>',
    'No amor, aquarianos são leais, mas valorizam a liberdade acima de tudo. Eles buscam parceiros que respeitem sua individualidade e compartilhem seus ideais, mas precisam trabalhar a conexão emocional.',
    'Aquário se destaca em carreiras que envolvem inovação, como tecnologia, ciência, ativismo ou artes experimentais. Eles prosperam em ambientes que permitem liberdade criativa, mas devem evitar a dispersão.',
    'Aquário combina com signos de <strong>Ar</strong> (Gêmeos, Libra), que compartilham sua mentalidade livre. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) estimulam sua energia. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) e <strong>Água</strong> (Câncer, Escorpião, Peixes) podem achar a natureza imprevisível de Aquário desafiadora.',
    'Regido por Urano, Aquário é movido pela inovação e mudança. Urano confere originalidade e visão, mas pode intensificar a imprevisibilidade. Atividades como voluntariado ou projetos criativos podem canalizar essa energia.',
    '<li><strong>Conecte-se emocionalmente:</strong> Trabalhe para expressar seus sentimentos com mais clareza.</li><li><strong>Ouça os outros:</strong> Esteja aberto a perspectivas diferentes para enriquecer suas ideias.</li><li><strong>Equilibre a rebeldia:</strong> Desafie normas com propósito, não apenas por impulso.</li><li><strong>Mantenha o foco:</strong> Estabeleça metas claras para suas visões inovadoras.</li>',
    '<li><strong>Oprah Winfrey:</strong> Apresentadora, conhecida por seu impacto humanitário.</li><li><strong>Harry Styles:</strong> Cantor, com um estilo único e original.</li><li><strong>Ellen DeGeneres:</strong> Apresentadora, cuja autenticidade inspira milhões.</li><li><strong>Justin Timberlake:</strong> Cantor, com uma carreira marcada por inovação.</li><li><strong>Alicia Keys:</strong> Cantora, cuja visão criativa reflete Aquário.</li>'
);

-- Inserindo os dados de Peixes
INSERT INTO signos (
    nome_signos, signo, icone, chamada, elemento, cor, planeta_regente, compatibilidade, periodo,
    introducao, mitologia, caracteristicas_positivas, caracteristicas_negativas,
    relacionamentos, carreira, compatibilidade_texto, influencia_planetaria, dicas, famosos
) VALUES (
    'Peixes',
    'pisces',
    '♓︎',
    'O Sonhador do Zodíaco',
    'Água',
    'Azul-marinho',
    'Netuno',
    'Câncer, Escorpião',
    '19 de Fevereiro à 20 de Março',
    'Peixes, o décimo segundo signo do zodíaco, é a essência da compaixão e da imaginação. Associado ao elemento <strong>Água</strong> e regido por <strong>Netuno</strong>, os nascidos entre <strong>19 de fevereiro e 20 de março</strong> são conhecidos por sua sensibilidade, intuição e criatividade. Como o signo dos peixes, Peixes nada nas profundezas emocionais, conectando-se com o mundo através do coração e da alma.',
    'Na mitologia grega, Peixes está associado a Afrodite e Eros, que se transformaram em peixes para escapar do monstro Tifão, nadando juntos no rio Eufrates. Sua imagem simboliza a conexão emocional e a fuga para um mundo de sonhos, características centrais de Peixes.',
    '<li><strong>Compaixão:</strong> Piscianos têm um coração generoso, sempre ajudando os outros.</li><li><strong>Criatividade:</strong> Sua imaginação é ilimitada, brilhando nas artes e na expressão.</li><li><strong>Intuição:</strong> Possuem uma sensibilidade quase mística para captar emoções.</li><li><strong>Empatia:</strong> Conectam-se profundamente com as emoções alheias.</li><li><strong>Adaptabilidade:</strong> Fluem com as mudanças, como a água que os representa.</li>',
    '<li><strong>Escapismo:</strong> Podem fugir da realidade, buscando refúgio em sonhos ou vícios.</li><li><strong>Hipersensibilidade:</strong> São facilmente afetados por críticas ou energias negativas.</li><li><strong>Indecisão:</strong> Sua natureza sonhadora pode dificultar a tomada de decisões.</li><li><strong>Autopiedade:</strong> Podem se vitimizar em momentos de dificuldade.</li>',
    'No amor, piscianos são românticos e sonhadores, buscando conexões espirituais. Eles se entregam completamente, mas precisam estabelecer limites para evitar se perderem no parceiro.',
    'Peixes se destaca em carreiras criativas ou de cuidado, como arte, música, terapia ou trabalho social. Eles prosperam em ambientes que permitem expressão emocional, mas devem evitar a desorganização.',
    'Peixes combina com signos de <strong>Água</strong> (Câncer, Escorpião), que compartilham sua sensibilidade. Signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) oferecem estabilidade. Signos de <strong>Fogo</strong> (Áries, Leão, Sagitário) e <strong>Ar</strong> (Gêmeos, Libra, Aquário) podem achar a intensidade emocional de Peixes avassaladora.',
    'Regido por Netuno, Peixes é movido pela intuição e pela imaginação. Netuno confere sensibilidade e criatividade, mas pode intensificar o escapismo. Atividades como meditação ou arte podem ajudar a equilibrar essa energia.',
    '<li><strong>Estabeleça limites:</strong> Proteja sua energia emocional para evitar esgotamento.</li><li><strong>Enfrente a realidade:</strong> Equilibre sonhos com ações práticas.</li><li><strong>Tome decisões:</strong> Confie em sua intuição, mas pratique escolhas assertivas.</li><li><strong>Cuide de si:</strong> Priorize seu bem-estar para evitar autopiedade.</li>',
    '<li><strong>Rihanna:</strong> Cantora, cuja criatividade e empatia brilham.</li><li><strong>Justin Bieber:</strong> Cantor, com uma sensibilidade artística marcante.</li><li><strong>Adam Levine:</strong> Cantor, cuja expressão emocional reflete Peixes.</li><li><strong>Elizabeth Taylor:</strong> Atriz, conhecida por sua compaixão e carisma.</li><li><strong>Kurt Cobain:</strong> Músico, cuja arte intensa capturou a essência pisciana.</li>'
);