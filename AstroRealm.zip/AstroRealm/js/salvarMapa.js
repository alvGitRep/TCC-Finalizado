const botaoSalvar = document.getElementById("salvarMapa");

botaoSalvar.addEventListener("click", () => {
    const titulo = prompt("Dê um título ao seu mapa:");

    if (!titulo) {
        alert("Título obrigatório.");
        return;
    }

    const dadosMapa = {
        nome: document.getElementById("nomeUsuario")?.innerText || "Desconhecido",
        data: document.getElementById("dataNasc")?.innerText || "Data não informada",
        criado_em: new Date().toLocaleString(),
        planetas: {
            sol: document.getElementById("signoSolar")?.innerText || "Desconhecido",
            lua: document.getElementById("signoLua")?.innerText || "Desconhecido",
            ascendente: document.getElementById("signoAscendente")?.innerText || "Desconhecido",
        }
    };

    fetch("php/salvar_mapa.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `titulo=${encodeURIComponent(titulo)}&dados_mapa=${encodeURIComponent(JSON.stringify(dadosMapa))}`
    })
    .then(res => res.text())
    .then(msg => alert(msg))
    .catch(err => {
        console.error(err);
        alert("Erro ao salvar o mapa.");
    });
});
