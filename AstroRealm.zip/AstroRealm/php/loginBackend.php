<?php
session_start();

require_once 'conexao.php';

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

$sql = "SELECT id, nome, senha, tipo_usuario, foto FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();

$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if ($usuario && password_verify($senha, $usuario['senha'])) {
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['usuario_nome'] = $usuario['nome'];
    $_SESSION['tipo_usuario'] = $usuario['tipo_usuario'];

    if (isset($_SESSION['redirecionar_para'])) {
        $destino = $_SESSION['redirecionar_para'];
        unset($_SESSION['redirecionar_para']);
        header("Location: ../$destino");
    } else {
        header("Location: ../index.php");
    }
    exit();
} else {
    header("Location: ../login.php?erro=1");
    exit();
}

$stmt->close();
$conn->close();
