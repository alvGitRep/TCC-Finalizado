document.addEventListener("DOMContentLoaded", () => {
    const paisDropdown = document.getElementById("paisDropdown");
    const selectedOption = paisDropdown.querySelector(".selected-option");
    const options = paisDropdown.querySelector(".options");
    const inputPais = document.getElementById("pais");
    const clicarDrop = document.getElementById("clicarDrop");

    // Alterna a visibilidade do dropdown ao clicar no elemento
    paisDropdown.addEventListener("click", (e) => {
        // Evita que o clique na lista propague e feche o dropdown imediatamente
        e.stopPropagation();
        paisDropdown.classList.toggle("open");
    });

    clicarDrop.addEventListener("click", (e) => {
        e.stopPropagation();
        paisDropdown.classList.toggle("open");
    });

    options.querySelectorAll("li").forEach(option => {
        option.addEventListener("click", (e) => {
            e.stopPropagation();
            const value = option.getAttribute("data-value");
            const label = option.textContent;

            selectedOption.textContent = label;
            inputPais.value = value;
            paisDropdown.classList.remove("open");
        });
    });

    document.addEventListener("click", (e) => {
        if (!paisDropdown.contains(e.target)) {
            paisDropdown.classList.remove("open");
        }
    });
});

const btnMapa = document.querySelector("#btnMapa");
const textosCentro = document.querySelector("#textosCentro");
const divForm = document.querySelector("#divForm");
const btnConfirmar = document.querySelector("#btnConfirmar");

btnMapa.addEventListener("click", () => {
    textosCentro.style.display = 'none';
    divForm.style.display = 'block';
    btnMapa.style.display = 'none';
    btnConfirmar.style.display = 'block';
});

btnConfirmar.addEventListener("click", () => {
    const nomeOpcional = document.querySelector("#nome").value;
    const pais = document.querySelector("#pais").value;
    const cidade = document.querySelector("#cidade").value;
    const data = document.querySelector("#data").value;
    const hora = document.querySelector("#hora").value;
    console.log(nomeOpcional);

    const nome = nomeOpcional || "Meu Nome";

    // console.log("Dados capturados do formulário:", { nome, pais, cidade, data, hora });

    if (!pais || !cidade || !data || !hora) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // salvar no sessionStorage
    sessionStorage.setItem("nome", nome);
    sessionStorage.setItem("pais", pais);
    sessionStorage.setItem("cidade", cidade);
    sessionStorage.setItem("data", data);
    sessionStorage.setItem("hora", hora);

    // Log para confirmar o salvamento
    console.log("Dados salvos no sessionStorage.");

    window.location.href = "meumapa.php";
});