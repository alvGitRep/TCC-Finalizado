<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once 'conexao.php';

$id = $_POST['id'] ?? 0;
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$tipo_usuario = $_POST['tipo_usuario'] ?? '';

$sql = "SELECT foto FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();
if (!$usuario) {
    header("Location: ../admin_gerenciar_usuarios.php?erro=" . urlencode("Usuário não encontrado"));
    exit();
}
$foto = $usuario['foto'];

if (isset($_FILES['foto']) && $_FILES['foto']['name']) {
    $target_dir = "../imagens/perfis/";
    $target_file = $target_dir . basename($_FILES['foto']['name']);
    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
        $foto = basename($_FILES['foto']['name']);
    } else {
        header("Location: ../admin_gerenciar_usuarios.php?erro=" . urlencode("Erro ao fazer upload da foto"));
        exit();
    }
}

$sql = "UPDATE usuarios SET nome = ?, email = ?, tipo_usuario = ?, foto = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $nome, $email, $tipo_usuario, $foto, $id);

try {
    $stmt->execute();
    if ($id == $_SESSION['usuario_id']) {
        $_SESSION['usuario_nome'] = $nome;
        $_SESSION['usuario_foto'] = $foto;
    }
    header("Location: ../admin_gerenciar_usuarios.php?sucesso=1");
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() == 1062) {
        header("Location: ../admin_gerenciar_usuarios.php?erro=" . urlencode("Este e-mail já está em uso."));
    } else {
        header("Location: ../admin_gerenciar_usuarios.php?erro=" . urlencode("Erro inesperado: " . $e->getMessage()));
    }
}

$stmt->close();
$conn->close();
?>