<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// Verifica se o ID do mapa foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: ../colecao.php");
    exit();
}

$mapa_id = (int)$_GET['id'];

require_once 'conexao.php';

$sql = "SELECT id FROM mapas_astrais WHERE id = ? AND usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $mapa_id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $stmt->close();
    $conn->close();
    header("Location: ../colecao.php");
    exit();
}

// Exclui o mapa
$sql = "DELETE FROM mapas_astrais WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mapa_id);
$stmt->execute();

$stmt->close();
$conn->close();

header("Location: ../colecao.php");
exit();
?>