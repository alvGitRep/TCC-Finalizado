<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once 'conexao.php';

$id = $_GET['id'] ?? 0;
if ($id == $_SESSION['usuario_id']) {
    header("Location: ../admin_gerenciar_usuarios.php?erro=nao_pode_excluir_proprio_usuario");
    exit();
}

$sql = "DELETE FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
header("Location: ../admin_gerenciar_usuarios.php?sucesso=1");
exit();

$stmt->close();
$conn->close();
