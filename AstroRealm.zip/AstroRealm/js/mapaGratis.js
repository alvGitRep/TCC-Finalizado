//=======================
//PEGANDO ELEMNTOS DO DOM
//=======================

const btnGerarGratis = document.querySelector("#btnGerarGratis");

btnGerarGratis.addEventListener("click", () => {

    const nomeOpcional = document.querySelector("#nome").value;
    const data = document.querySelector("#data").value;
    const hora = document.querySelector("#hora").value;
    const cidade = document.querySelector("#cidade").value;
    const pais = document.querySelector("#pais").value;

    const nome = nomeOpcional || "Meu Nome";

    if (!nome || !pais || !cidade || !data || !hora) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    sessionStorage.setItem("nome", nome);
    sessionStorage.setItem("pais", pais);
    sessionStorage.setItem("cidade", cidade);
    sessionStorage.setItem("data", data);
    sessionStorage.setItem("hora", hora);

    window.location.href = "meumapa.php";
});