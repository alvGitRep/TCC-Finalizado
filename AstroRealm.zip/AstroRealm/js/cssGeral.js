document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const menu = document.querySelector('#listaMenu');
    const dropdowns = document.querySelectorAll('.dropdown');

    if (hamburger && menu) {
        hamburger.addEventListener('click', () => {
            menu.classList.toggle('active');
        });
    }

    dropdowns.forEach(dropdown => {
        const toggleButton = dropdown.querySelector('.dropdown-toggle');
        const dropdownContent = dropdown.querySelector('.dropdown-content');
        const horoscopoLink = dropdown.querySelector('a'); // The "Horóscopo" link

        if (toggleButton) {
            toggleButton.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent click from bubbling to document
                if (window.innerWidth <= 576) {
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                    // Close other dropdowns
                    dropdowns.forEach(otherDropdown => {
                        if (otherDropdown !== dropdown) {
                            otherDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

        // Ensure dropdown-content links are clickable when dropdown is open
        const dropdownContentLinks = dropdown.querySelectorAll('.dropdown-content a');
        dropdownContentLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent click from bubbling to document
                if (window.innerWidth <= 576 && !dropdown.classList.contains('active')) {
                    e.preventDefault(); // Prevent navigation if dropdown is not open
                } else if (window.innerWidth <= 576) {
                    dropdown.classList.remove('active'); // Close dropdown after link click
                }
            });
        });

        // Prevent clicks inside dropdown-content from closing it
        if (dropdownContent) {
            dropdownContent.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent click from bubbling to document
            });
        }

        // Prevent clicks on the "Horóscopo" link from closing the dropdown
        if (horoscopoLink) {
            horoscopoLink.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent click from bubbling to document
                // Allow navigation to horoscopo.php without closing dropdown
            });
        }
    });

    // Close dropdowns when clicking outside dropdown-content
    document.addEventListener('click', (e) => {
        dropdowns.forEach(dropdown => {
            const dropdownContent = dropdown.querySelector('.dropdown-content');
            if (dropdownContent && !dropdownContent.contains(e.target) && dropdown.classList.contains('active')) {
                dropdown.classList.remove('active');
            }
        });
    });

    // Manipulação do botão scrollToTopBtn
    const btn = document.getElementById('scrollToTopBtn');
    if (btn) {
        window.addEventListener('scroll', () => {
            if (document.body.scrollTop > 900 || document.documentElement.scrollTop > 900) {
                btn.style.display = "block";
            } else {
                btn.style.display = "none";
            }
        });

        btn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
});