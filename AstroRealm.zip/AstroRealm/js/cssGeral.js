document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const menu = document.querySelector('#listaMenu');
    const dropdowns = document.querySelectorAll('.dropdown');

    if (hamburger && menu) {
        hamburger.addEventListener('click', () => {
            menu.classList.toggle('active');
        });
    }

    dropdowns.forEach(dropdown => {
        const toggleButton = dropdown.querySelector('.dropdown-toggle');
        const dropdownContent = dropdown.querySelector('.dropdown-content');
        const horoscopoLink = dropdown.querySelector('a');

        if (toggleButton) {
            toggleButton.addEventListener('click', (e) => {
                e.stopPropagation();
                if (window.innerWidth <= 576) {
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                 
                    dropdowns.forEach(otherDropdown => {
                        if (otherDropdown !== dropdown) {
                            otherDropdown.classList.remove('active');
                        }
                    });
                }
            });
        }

      
        const dropdownContentLinks = dropdown.querySelectorAll('.dropdown-content a');
        dropdownContentLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.stopPropagation();
                if (window.innerWidth <= 576 && !dropdown.classList.contains('active')) {
                    e.preventDefault(); 
                } else if (window.innerWidth <= 576) {
                    dropdown.classList.remove('active');
                }
            });
        });

     
        if (dropdownContent) {
            dropdownContent.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }

        
        if (horoscopoLink) {
            horoscopoLink.addEventListener('click', (e) => {
                e.stopPropagation();
                
            });
        }
    });

    
    document.addEventListener('click', (e) => {
        dropdowns.forEach(dropdown => {
            const dropdownContent = dropdown.querySelector('.dropdown-content');
            if (dropdownContent && !dropdownContent.contains(e.target) && dropdown.classList.contains('active')) {
                dropdown.classList.remove('active');
            }
        });
    });

   
    const btn = document.getElementById('scrollToTopBtn');
    if (btn) {
        window.addEventListener('scroll', () => {
            if (document.body.scrollTop > 900 || document.documentElement.scrollTop > 900) {
                btn.style.display = "block";
            } else {
                btn.style.display = "none";
            }
        });

        btn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
});