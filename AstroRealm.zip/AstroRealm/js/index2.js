document.addEventListener("DOMContentLoaded", () => {
    const paisDropdown = document.getElementById("paisDropdown");
    const selectedOption = paisDropdown.querySelector(".selected-option");
    const options = paisDropdown.querySelector(".options");
    const inputPais = document.getElementById("pais");
    const clicarDrop = document.getElementById("clicarDrop");

    // Alterna a visibilidade do dropdown ao clicar no elemento
    paisDropdown.addEventListener("click", (e) => {
        // Evita que o clique na lista propague e feche o dropdown imediatamente
        e.stopPropagation();
        paisDropdown.classList.toggle("open");
    });

    clicarDrop.addEventListener("click", (e) => {
        // Evita que o clique na lista propague e feche o dropdown imediatamente
        e.stopPropagation();
        paisDropdown.classList.toggle("open");
    });

    // Adiciona evento de clique para cada opção do dropdown
    options.querySelectorAll("li").forEach(option => {
        option.addEventListener("click", (e) => {
            e.stopPropagation(); // Impede propagação para evitar conflitos
            const value = option.getAttribute("data-value");
            const label = option.textContent;

            selectedOption.textContent = label; // Atualiza o texto visível
            inputPais.value = value; // Atualiza o input escondido
            paisDropdown.classList.remove("open"); // Fecha o dropdown
        });
    });

    // Fecha o dropdown ao clicar fora dele
    document.addEventListener("click", (e) => {
        if (!paisDropdown.contains(e.target)) {
            paisDropdown.classList.remove("open");
        }
    });
});

// Código para os botões "Criar Mapa" e "Confirmar"
const btnMapa = document.querySelector("#btnMapa");
const textosCentro = document.querySelector("#textosCentro");
const divForm = document.querySelector("#divForm");
const btnConfirmar = document.querySelector("#btnConfirmar");

btnMapa.addEventListener("click", () => {
    textosCentro.style.display = 'none';
    divForm.style.display = 'block';
    btnMapa.style.display = 'none';
    btnConfirmar.style.display = 'block';
});

btnConfirmar.addEventListener("click", () => {
    // Capturar os dados do formulário
    const nomeOpcional = document.querySelector("#nome").value;
    const pais = document.querySelector("#pais").value;
    const cidade = document.querySelector("#cidade").value;
    const data = document.querySelector("#data").value;
    const hora = document.querySelector("#hora").value;
    console.log(nomeOpcional);

    // if (!nome) {
    //     nome = "Meu Nome";
    // }

    const nome = nomeOpcional || "Meu Nome";

    // Log para verificar os valores capturados
    // console.log("Dados capturados do formulário:", { nome, pais, cidade, data, hora });

    // Validar se os campos estão preenchidos
    if (!pais || !cidade || !data || !hora) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Salvar os dados no sessionStorage
    sessionStorage.setItem("nome", nome);
    sessionStorage.setItem("pais", pais);
    sessionStorage.setItem("cidade", cidade);
    sessionStorage.setItem("data", data);
    sessionStorage.setItem("hora", hora);

    // Log para confirmar o salvamento
    console.log("Dados salvos no sessionStorage.");

    // Redirecionar para a página de exibição
    window.location.href = "meumapa.php";
});